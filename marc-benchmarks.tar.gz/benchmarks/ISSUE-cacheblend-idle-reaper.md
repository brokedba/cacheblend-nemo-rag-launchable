# Bug: CacheBlend silently loses caching after ~1h idle (GPU instance reaped, never restored)

**Date found:** 2026-08-09
**Where:** `gptoss120b-cb-colo` deployment, `cacheblend-workload` namespace (CacheBlend/LMCache MP stack)
**Impact:** server keeps serving requests and looks healthy, but every cache lookup fails —
it silently degrades to a no-cache baseline. Any benchmark or demo run after an idle period
measures the wrong thing with no visible error at the API level.

## Timeline (from pod logs)

```
2026-08-08 03:46:18  LMCache MP worker adapter created with instance_id=1303395710956992538
2026-08-08 04:46:21  LMCache WARNING: Reaped GPU instance 1303395710956992538: silent for 3602.3s
                     (pinged=False)  (lmcache_driven_transfer.py:776)
   ... pod idle ~25h, still Ready, still serving ...
2026-08-09 05:58:58  benchmark traffic starts; CB plugin re-registers RoPE state
                     ("Registering CB rope ..." / "Registered CB rope state for instance ...")
2026-08-09 05:58:58+ EVERY lookup fails:
                     LMCache ERROR: No CB GPU context for model ... ws 1 during prefix lookup!
                     (blend_v3.py:1114)  — 32 occurrences in 45s, zero cache hits
```

## Root cause (as observed)

The idle reaper drops the GPU-instance registration after 1h of silence
(`pinged=False` — the engine side apparently does not heartbeat while idle).
On the next request, only the RoPE state is re-registered; the CB GPU context
required by `blend_v3` prefix lookup is never restored. There is no recovery
path short of a pod restart, and no error surfaces to clients.

## Workaround

1. Restart the deployment: `kubectl rollout restart deploy/gptoss120b-cb-colo -n cacheblend-workload`.
   Fresh startup re-registers instance + CB rope; verified working afterwards
   (`[match_probe] ... table_hits=...`, `Retrieved 768 tokens in 0.001 seconds`, hit rate > 0).
2. Note: the deployment strategy was patched to `Recreate` on 2026-08-09 — with
   RollingUpdate the replacement pod deadlocks on the single-GPU node (old pod
   holds the GPU, new pod Pending with `Insufficient nvidia.com/gpu`).

## Detection / prevention

- Before any benchmark against cb-colo, check:
  `kubectl logs deploy/gptoss120b-cb-colo -c engine --since=5m | grep -c "No CB GPU context"`
  (must be 0, and a repeated smoke request should log `Retrieved N tokens`).
- Suggested fixes upstream: heartbeat the GPU instance while idle (`pinged=False` suggests
  the ping path is broken/disabled), or make the lookup path re-register the GPU context
  on demand the same way RoPE state is re-registered, or at minimum fail loudly/unready.

## Benchmark impact

- The first `cacheblend-r85` launch on 2026-08-09 (~05:58) ran ~10 min of unmeasured
  prewarm against the broken cache and was aborted + deleted; no measured data was taken.
- `lmcache-r85` results are unaffected. The relaunched `cacheblend-r85` run started after
  the restart with CB verified healthy (0 errors, hits observed via smoke test).
