#!/usr/bin/env python3
"""Round two, chat leg: tuned-vLLM-recipe vs recipe-tuned CacheBlend on the
chat18k dataset (16k shared prefix from 8 tenants + 2k unique, ISL ~18k,
OSL 100, ~88% prefix-shaped reuse). Same panels/metrics as plot_comparison.py
(r85/2k figures) so the report figures read consistently.

Reads results/<leg>/c<N>/<leg>_c<N>.json, writes:
  round2-chat18k-comparison.png   4-panel figure
  round2-chat18k-comparison.csv   per-point metrics table
"""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

BASE = Path(__file__).parent / "results"
LEGS = [
    ("recipe-chat18k", "Tuned vLLM (fp8 KV)", "#1baf7a"),
    ("recipe-bf16-chat18k", "Tuned vLLM (bf16 KV, config-matched)", "#2a78d6"),
    ("round2-tuned-cb-chat18k", "CacheBlend (recipe-tuned)", "#eb6834"),
]
CONCURRENCIES = [1, 2, 4, 8, 16, 32]

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

data = {}
for leg, _, _ in LEGS:
    for c in CONCURRENCIES:
        with open(BASE / leg / f"c{c}" / f"{leg}_c{c}.json") as f:
            data[(leg, c)] = json.load(f)


def metric(leg, c, name, stat="avg"):
    return data[(leg, c)][name][stat]


def total_tok_s(leg, c):
    rps = metric(leg, c, "request_throughput")
    isl = metric(leg, c, "input_sequence_length")
    osl = metric(leg, c, "output_sequence_length")
    return rps * (isl + osl)


plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans"],
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "axes.edgecolor": AXIS,
    "axes.labelcolor": INK,
    "text.color": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})

from matplotlib.lines import Line2D
def legend_with_x(ax, **kw):
    h, l = ax.get_legend_handles_labels()
    h += [Line2D([0], [0], linestyle="none", marker=r"$\mathbf{\times}$", markersize=9, color="#2a78d6"),
          Line2D([0], [0], linestyle="none", marker=r"$\mathbf{\times}$", markersize=9, color="#1baf7a")]
    l += ["CacheBlend advantage vs bf16 (config-matched)", "CacheBlend advantage vs fp8"]
    ax.legend(h, l, frameon=False, fontsize=8.5, **kw)

fig, axes = plt.subplots(2, 2, figsize=(12, 9))
fig.suptitle(
    "CHAT prefix-reuse benchmark, round two — GPT-OSS-120B, 1 GPU, ISL ~18k / OSL 100, reuse ~0.88 prefix-shaped",
    fontsize=12, fontweight="bold", y=0.98,
)

# Panel 1: TTFT p90 vs concurrency (log-log: values span 0.4s..20s)
ax = axes[0][0]
for leg, label, color in LEGS:
    ys = [metric(leg, c, "time_to_first_token", "p90") / 1000 for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2); ax.set_yscale("log")
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_yticks([0.5, 1, 2, 5, 10, 20]); ax.get_yaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("TTFT p90 (s)")
ax.set_title("Time to first token (p90) — lower is better", fontsize=10)
for c in CONCURRENCIES:
    fp8 = metric("recipe-chat18k", c, "time_to_first_token", "p90") / 1000
    bf16 = metric("recipe-bf16-chat18k", c, "time_to_first_token", "p90") / 1000
    cb = metric("round2-tuned-cb-chat18k", c, "time_to_first_token", "p90") / 1000
    mg, mb = (fp8 * cb) ** 0.5, (bf16 * cb) ** 0.5
    off_g, off_b = ((0, 9), (0, -11)) if mg >= mb else ((0, -11), (0, 9))
    ax.annotate(f"{fp8 / cb:.1f}×", (c, mg), fontsize=8.5,
                color="#1baf7a", ha="center", va="center", textcoords="offset points", xytext=off_g,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
    ax.annotate(f"{bf16 / cb:.1f}×", (c, mb), fontsize=8.5,
                color="#2a78d6", ha="center", va="center", textcoords="offset points", xytext=off_b,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
legend_with_x(ax, loc="upper left")

# Panel 2: ITL p90 vs concurrency
ax = axes[0][1]
for leg, label, color in LEGS:
    ys = [metric(leg, c, "inter_token_latency", "p90") for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2)
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("ITL p90 (ms)")
ax.set_yscale("log")
ax.set_yticks([5, 10, 25, 50, 100, 250]); ax.get_yaxis().set_major_formatter(ScalarFormatter())
ax.set_title("Inter-token latency (p90, log scale) — lower is better", fontsize=10)
ax.legend(frameon=False, fontsize=9, loc="upper left")

# Panel 3: total tok/s/GPU vs concurrency
ax = axes[1][0]
for leg, label, color in LEGS:
    ys = [total_tok_s(leg, c) for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2)
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("total tokens served / s / GPU")
ax.set_ylim(0, None)
ax.set_title("Throughput per GPU (input+output tokens) — higher is better", fontsize=10)
for c in CONCURRENCIES:
    fp8, bf16, cb = total_tok_s("recipe-chat18k", c), total_tok_s("recipe-bf16-chat18k", c), total_tok_s("round2-tuned-cb-chat18k", c)
    mg, mb = (fp8 + cb) / 2, (bf16 + cb) / 2
    off_g, off_b = ((0, 9), (0, -11)) if mg >= mb else ((0, -11), (0, 9))
    ax.annotate(f"{cb / fp8:.2f}×", (c, mg), fontsize=8.5,
                color="#1baf7a", ha="center", va="center", textcoords="offset points", xytext=off_g,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
    ax.annotate(f"{cb / bf16:.2f}×", (c, mb), fontsize=8.5,
                color="#2a78d6", ha="center", va="center", textcoords="offset points", xytext=off_b,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
legend_with_x(ax, loc="lower right")

# Panel 4: Pareto — total tok/s/GPU vs end-to-end per-user token rate.
ax = axes[1][1]
for leg, label, color in LEGS:
    xs = [metric(leg, c, "output_sequence_length") / (metric(leg, c, "request_latency") / 1000)
          for c in CONCURRENCIES]
    ys = [total_tok_s(leg, c) for c in CONCURRENCIES]
    ax.plot(xs, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
    for c, x, y in zip(CONCURRENCIES, xs, ys):
        ax.annotate(f"c={c}", (x, y), textcoords="offset points",
                    xytext=(4, 6) if leg.startswith("round2-") else (4, -12),
                    fontsize=8, color=MUTED)
ax.set_xscale("log")
ax.set_xticks([5, 10, 30, 80]); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("end-to-end tokens/s/user (OSL / request latency, incl. queue+prefill)")
ax.set_ylabel("total tokens served / s / GPU")
ax.set_ylim(0, None)
ax.set_title("Throughput vs per-user token rate — up and right is better", fontsize=10)
ax.legend(frameon=False, fontsize=9, loc="lower left")

fig.text(0.5, 0.005,
         "Each point = its own aiperf run with its own seed (fresh 8 tenant prefixes) after a 40-request warmup that fills them.\n"
         "ITL reflects decode pacing only; queue wait appears in TTFT and in the per-user token rate (panel 4).\n"
         "× labels = CacheBlend's advantage: blue × vs bf16 config-matched, green × vs fp8 (>1× = CacheBlend better).\n"
         "Both arms cache ~88% of each prompt; the tuned arm hits via vLLM APC (GPU-resident), "
         "CacheBlend via its content-addressed blend path (+ APC on this deployment).",
         fontsize=8, color=MUTED, ha="center")
fig.tight_layout(rect=(0.01, 0.05, 0.99, 0.96))
out_png = Path(__file__).parent / "round2-chat18k-comparison.png"
fig.savefig(out_png, dpi=150)
print(f"wrote {out_png}")

# CSV with full percentiles
out_csv = Path(__file__).parent / "round2-chat18k-comparison.csv"
pcts = ["avg", "p50", "p90", "p95", "p99", "min", "max"]
with open(out_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["leg", "concurrency", "requests", "isl_avg", "req_per_s", "total_tok_per_s", "req_latency_avg_ms"]
               + [f"ttft_{p}_ms" for p in pcts] + [f"itl_{p}_ms" for p in pcts])
    for leg, _, _ in LEGS:
        for c in CONCURRENCIES:
            d = data[(leg, c)]
            w.writerow(
                [leg, c, d["request_count"]["avg"], round(metric(leg, c, "input_sequence_length"), 1),
                 round(metric(leg, c, "request_throughput"), 3), round(total_tok_s(leg, c), 1),
                 round(metric(leg, c, "request_latency"), 1)]
                + [round(d["time_to_first_token"][p], 1) for p in pcts]
                + [round(d["inter_token_latency"][p], 2) for p in pcts])
print(f"wrote {out_csv}")
