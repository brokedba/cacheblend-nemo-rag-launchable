#!/usr/bin/env python3
"""4-panel LMCache-baseline vs CacheBlend comparison from local aiperf results.

Reads results/<leg>/c<N>/<leg>_c<N>.json, writes:
  chat-18k-comparison.png   4-panel figure
  chat-18k-comparison.csv   per-point metrics table (all percentiles for TTFT/ITL)
"""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

BASE = Path(__file__).parent / "results"
LEGS = [
    ("lmcache-chat18k", "LMCache (default retrieval)", "#2a78d6"),
    ("cacheblend-chat18k", "CacheBlend", "#eb6834"),
    ("recipe-chat18k", "Tuned vLLM (APC, no cache product)", "#1baf7a"),
]
CONCURRENCIES = [1, 2, 4, 8, 16, 32]

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

data = {}
for leg, _, _ in LEGS:
    for c in CONCURRENCIES:
        with open(BASE / leg / f"c{c}" / f"{leg}_c{c}.json") as f:
            data[(leg, c)] = json.load(f)


def metric(leg, c, name, stat="avg"):
    return data[(leg, c)][name][stat]


def total_tok_s(leg, c):
    rps = metric(leg, c, "request_throughput")
    isl = metric(leg, c, "input_sequence_length")
    osl = metric(leg, c, "output_sequence_length")
    return rps * (isl + osl)


plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans"],
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "axes.edgecolor": AXIS,
    "axes.labelcolor": INK,
    "text.color": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})

from matplotlib.lines import Line2D
def legend_with_x(ax, **kw):
    h, l = ax.get_legend_handles_labels()
    h += [Line2D([0], [0], linestyle="none", marker=r"$\mathbf{\times}$", markersize=9, color="#2a78d6"),
          Line2D([0], [0], linestyle="none", marker=r"$\mathbf{\times}$", markersize=9, color="#1baf7a")]
    l += ["CacheBlend advantage vs LMCache", "CacheBlend advantage vs tuned vLLM"]
    ax.legend(h, l, frameon=False, fontsize=8.5, **kw)

fig, axes = plt.subplots(2, 2, figsize=(12, 9))
fig.suptitle(
    "CHAT prefix-reuse benchmark — GPT-OSS-120B, 1 GPU, ISL ~18k (16k shared prefix) / OSL 100, reuse ~0.88",
    fontsize=12, fontweight="bold", y=0.98,
)

# Panel 1: TTFT p90 vs concurrency (log-log: values span 2s..110s)
ax = axes[0][0]
for leg, label, color in LEGS:
    ys = [metric(leg, c, "time_to_first_token", "p90") / 1000 for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2); ax.set_yscale("log")
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_yticks([2, 5, 10, 30, 60, 120]); ax.get_yaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("TTFT p90 (s)")
ax.set_title("Time to first token (p90) — lower is better", fontsize=10)
# per-point CacheBlend advantage, color-coded by opponent (>1 = CB better):
# blue x = vs LMCache, green x = vs tuned vLLM; dodged left/right to avoid collisions
for c in CONCURRENCIES:
    base = metric("lmcache-chat18k", c, "time_to_first_token", "p90") / 1000
    cb = metric("cacheblend-chat18k", c, "time_to_first_token", "p90") / 1000
    rc = metric("recipe-chat18k", c, "time_to_first_token", "p90") / 1000
    mb, mg = (base * cb) ** 0.5, (rc * cb) ** 0.5
    off_b, off_g = ((0, 9), (0, -11)) if mb >= mg else ((0, -11), (0, 9))
    ax.annotate(f"{base / cb:.1f}×", (c, mb), fontsize=8.5,
                color="#2a78d6", ha="center", va="center", textcoords="offset points", xytext=off_b,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
    ax.annotate(f"{rc / cb:.1f}×", (c, mg), fontsize=8.5,
                color="#1baf7a", ha="center", va="center", textcoords="offset points", xytext=off_g,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
legend_with_x(ax, loc="upper left")

# Panel 2: ITL p90 vs concurrency
ax = axes[0][1]
for leg, label, color in LEGS:
    ys = [metric(leg, c, "inter_token_latency", "p90") for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2)
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("ITL p90 (ms)")
ax.set_ylim(0, None)
ax.set_title("Inter-token latency (p90) — lower is better", fontsize=10)
ax.legend(frameon=False, fontsize=9, loc="upper right")

# Panel 3: total tok/s/GPU vs concurrency
ax = axes[1][0]
for leg, label, color in LEGS:
    ys = [total_tok_s(leg, c) for c in CONCURRENCIES]
    ax.plot(CONCURRENCIES, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
ax.set_xscale("log", base=2)
ax.set_xticks(CONCURRENCIES); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("concurrency"); ax.set_ylabel("total tokens served / s / GPU")
ax.set_ylim(0, None)
ax.set_title("Throughput per GPU (input+output tokens) — higher is better", fontsize=10)
# per-point CacheBlend advantage, color-coded by opponent (>1 = CB better)
for c in CONCURRENCIES:
    base, cb = total_tok_s("lmcache-chat18k", c), total_tok_s("cacheblend-chat18k", c)
    rc = total_tok_s("recipe-chat18k", c)
    mb, mg = (base + cb) / 2, (rc + cb) / 2
    off_b, off_g = ((0, 9), (0, -11)) if mb >= mg else ((0, -11), (0, 9))
    ax.annotate(f"{cb / base:.2f}×", (c, mb), fontsize=8.5,
                color="#2a78d6", ha="center", va="center", textcoords="offset points", xytext=off_b,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
    ax.annotate(f"{cb / rc:.2f}×", (c, mg), fontsize=8.5,
                color="#1baf7a", ha="center", va="center", textcoords="offset points", xytext=off_g,
                bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none", alpha=0.8))
legend_with_x(ax, loc="lower right")

# Panel 4: Pareto — total tok/s/GPU vs end-to-end per-user token rate.
# (1000/ITL is meaningless here: decode pacing is ~25ms at every load, so it
# collapses to one x-value. OSL / request latency includes queue + prefill,
# which is where this workload's user experience actually lives.)
ax = axes[1][1]
for leg, label, color in LEGS:
    xs = [metric(leg, c, "output_sequence_length") / (metric(leg, c, "request_latency") / 1000)
          for c in CONCURRENCIES]
    ys = [total_tok_s(leg, c) for c in CONCURRENCIES]
    ax.plot(xs, ys, color=color, marker="o", markersize=5, linewidth=2, label=label)
    for c, x, y in zip(CONCURRENCIES, xs, ys):
        ax.annotate(f"c={c}", (x, y), textcoords="offset points",
                    xytext=(4, 6) if leg.startswith("cacheblend") else (4, -12),
                    fontsize=8, color=MUTED)
ax.set_xscale("log")
ax.set_xticks([1, 3, 10, 30]); ax.get_xaxis().set_major_formatter(ScalarFormatter())
ax.set_xlabel("end-to-end tokens/s/user (OSL / request latency, incl. queue+prefill)")
ax.set_ylabel("total tokens served / s / GPU")
ax.set_ylim(0, None)
ax.set_title("Throughput vs per-user token rate — up and right is better", fontsize=10)
ax.legend(frameon=False, fontsize=9, loc="lower left")

fig.text(0.5, 0.005,
         "Each point = its own aiperf run with its own seed (fresh synthetic prompts, no replay) after a 40-request unmeasured warmup that fills that point's 8 prefixes.\n"
         "ITL reflects decode pacing only; queue wait appears in TTFT and panel 4. The × labels show CacheBlend's advantage, color-coded by opponent:\n"
         "blue × = CacheBlend vs LMCache, green × = CacheBlend vs tuned vLLM (>1× = CacheBlend better in both).\n"
         "Tuned-vLLM c=2 is a protocol-identical replicate (original run measured TTFT p90 6.1 s / 11.0k tok/s, a non-reproducible transient).",
         fontsize=8, color=MUTED, ha="center")
fig.tight_layout(rect=(0.01, 0.05, 0.99, 0.96))
out_png = Path(__file__).parent / "chat-18k-comparison.png"
fig.savefig(out_png, dpi=150)
print(f"wrote {out_png}")

# CSV with full percentiles
out_csv = Path(__file__).parent / "chat-18k-comparison.csv"
pcts = ["avg", "p50", "p90", "p95", "p99", "min", "max"]
with open(out_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["leg", "concurrency", "requests", "isl_avg", "req_per_s", "total_tok_per_s"]
               + [f"ttft_{p}_ms" for p in pcts] + [f"itl_{p}_ms" for p in pcts])
    for leg, _, _ in LEGS:
        for c in CONCURRENCIES:
            d = data[(leg, c)]
            w.writerow(
                [leg, c, d["request_count"]["avg"], round(metric(leg, c, "input_sequence_length"), 1),
                 round(metric(leg, c, "request_throughput"), 3), round(total_tok_s(leg, c), 1)]
                + [round(d["time_to_first_token"][p], 1) for p in pcts]
                + [round(d["inter_token_latency"][p], 2) for p in pcts])
print(f"wrote {out_csv}")
