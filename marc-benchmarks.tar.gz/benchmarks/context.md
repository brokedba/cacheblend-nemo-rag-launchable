# TensorMesh / CacheBlend POC — session context (updated 2026-08-13)

Load this to resume. Working dir: `~/Desktop/benchmarks/`. Cluster: try-70986-gpu01,
namespace `cacheblend-workload` (older dynamo-test namespace is empty). Node has 2 GPUs
(RTX PRO 6000 Blackwell 96GB); max two arms at once.

## Goal

Compare KV-cache strategies for GPT-OSS-120B, bracketed by two workloads:
- **RAG** (`rag_r85`): ~84% token reuse at SHUFFLED positions → prefix caching blind, CacheBlend's home turf
- **Chat** (`chat18k`): ~88% reuse as SHARED PREFIX (16k prefix + 2k unique, 8 tenants) → prefix caching's home turf

Both: ISL ~18k, OSL 100 (forced, ignore_eos+min_tokens), sweep c=1,2,4,8,16,32
(counts 30/30/40/80/160/320), single GPU per arm, 68k-token GPU KV (~3 residents).

## Arms

| Arm | What | Status |
|---|---|---|
| `gptoss120b-lmcache` | Marc's baseline: LMCache in-process connector, exact-prefix, 200GB CPU cache, `LMCACHE_USE_LAYERWISE=False` (default → blocking bulk retrieval — KEY FINDING) | RUNNING |
| `gptoss120b-cb-colo` | Kosseila's CacheBlend: blend server in-pod (`cb.check_layer=2, recomp_ratio=0.15`) | RUNNING |
| `gptoss120b-base` | Kosseila's no-cache vanilla (different scheduling, 45k len) | scaled to 0 |
| `gptoss120b-recipe` | DRAFTED, NOT APPLIED: optimized vanilla vLLM (APC + chunked prefill + fp8 KV + async sched + CUDA graphs + SimpleCPUOffloadConnector), from dynamo recipe gpt-oss-120b/agg-h200-agentic | yaml ready |

All arms: `enable_prefix_caching=False`, no chunked prefill, enforce-eager (CacheBlend
stack constraints, mirrored on baseline for clean ablation) — EXCEPT the recipe arm which
deliberately enables everything.

## Results so far (all 4 legs done, data local in `results/`)

### RAG (rag_r85): CacheBlend wins
- TTFT p90: 1.7× faster at c=1–2; throughput plateau 7,278 vs 5,111 tok/s (~1.45×)
- LMCache baseline hit 0 tokens on every request (prefix-chained lookup can't match shuffled chunks)
- ITL: baseline spikes to 54–87ms p90 at c=4–8 (uninterruptible 3s prefills stall decodes;
  self-synchronizing convoys fix it at c≥16); CacheBlend flat ~25ms

### RAG 2k chunks (rag_2k, NEW 2026-08-12/13): CacheBlend wins e2e at every load
Scaled-up RAG variant: 2048-token chunks (vs r85's 1024), 16 chunks/req
(12 hot + 2 cold + 2 supporting), ISL ~35k, reuse ~0.85, OSL 100. Legs:
`recipe-2k` (tuned-vLLM recipe baseline) vs `cb-recipe-2k` (CacheBlend), c=1..32.
- E2E request latency: CB 1.08×–1.41× faster at every concurrency (peak at c=4–8);
  throughput plateau ~6.5–6.8k vs ~4.9k tok/s (~1.35×) — recipe saturates at c=1
  (prefill-bound, extra load just queues)
- TTFT c=1: CB avg 4.3s vs 6.6s; CB p50 4.25s but p99 7.2s == baseline —
  cold-miss requests fall back to full 35k prefill (band plot shows the hit/miss split)
- TTFT avg at c=16/32 looks WORSE for CB (scheduling artifact) but p99 TTFT and
  request latency are clearly better — quote e2e latency, not avg TTFT, at high load
- ITL: same ~25ms CB decode floor as r85 (vs 7.5ms recipe at c=1); recipe ITL
  collapses to 695/1149ms avg at c=16/32 (35k ~7s uninterruptible prefills stall
  decodes — worse than r85 because prefills are 2× longer), CB holds ~325ms
- Bigger ISL preserved the relative TTFT gain and AMPLIFIED the high-load ITL gap
- CONFIG ASYMMETRY (called out in HTML warn box): recipe arm = fp8 KV (494k pool) +
  CUDA graphs + chunked prefill; CB arm = bf16 KV (181k pool, fp8 dropped 08-12) +
  enforce-eager + no chunked prefill. All deltas favor the recipe → CB's 1.08–1.41×
  e2e win is a LOWER BOUND for a config-matched comparison
- Gotcha: server not reporting usage.prompt_tokens_details.cached_tokens
  (vLLM `--enable-prompt-tokens-details`) → aiperf prompt-cache metrics empty;
  reuse is inferred, not measured. Enable before next run.

### Chat round two (round2-tuned-cb-chat18k, 2026-08-13): verdict FLIPS
Recipe-tuned CB (gptoss120b-cb-recipe) vs recipe-chat18k, same seeds → identical
prompts. Round one said "tuned vLLM beats both at high load" — no longer:
- CB wins c≥4 on throughput (up to 1.70× at c=16, peak 35.4k vs 20.8k tok/s)
  and e2e latency (1.39–1.71×); ITL stays 25–51ms vs recipe's 78–134ms
- Tuned vLLM keeps c=1 e2e (CB decode floor 25ms → 100-tok answer 2.7s vs 1.2s)
  and c=32 TTFT (chunked-prefill admission; CB still edges e2e 20.2 vs 22.0s)
- cb-colo plateaued ~15k on chat; cb-recipe hits 35.4k → most of round one's
  chat gap was stack tuning (APC on, 8 prefixes GPU-resident in 181k pool,
  async sched), not caching strategy
- Documented in HTML as own "Round two — Chat" section + figure
  (round2-chat18k-comparison.{png,csv} from plot_round2_chat_comparison.py)

### Positioning framing (user direction 2026-08-13)
Lead with TTFT — that's what CacheBlend is for. CB was fastest-to-first-token at
interactive/moderate load in EVERY leg on both geometries vs every baseline; its
TTFT losses at deep saturation are queue admission (chunked prefill), not prefill
speed. Decode floor is a stack cost, not blending. Natural home = PREFILL side of
P/D-disaggregated serving (decode workers keep CUDA graphs/fp8 → floor never
reaches users). Added to HTML as "Positioning" section (ok + warn boxes) before
"Verified working"; explicitly marked architectural-argument-not-measured;
P/D-disagg leg = natural round three.

### bf16 fairness ablation (DONE 2026-08-13, documented in HTML)
gptoss120b-recipe redeployed via gptoss120b-recipe-bf16.yaml — single-flag
delta: kv-cache-dtype fp8→auto(bf16), KV pool 494k→248,162 tokens (verified).
Results: results/{recipe-bf16-2k, recipe-bf16-chat18k}, 0 errors all points.
- RAG: bf16 costs the recipe ~10–15% tok/s (4.1–4.4k vs 4.9–5.1k); c=32 TTFT p90
  blows out 132→210s. Config-matched, CB wins TTFT at EVERY c (1.3–1.6×) and
  e2e 1.22–1.57× (vs 1.08–1.41× vs fp8).
- Chat: bf16 ≈ fp8 at low c; c=32 TTFT 10.0→23.3s (fp8's big pool was the win)
  → CB now takes c=32 TTFT too; only c=1 e2e loss survives (CUDA-graph decode,
  not fp8). NOTE: bf16 c=2 TTFT 5.9s = likely same non-reproducible c=2
  transient as round one — BUT a seed-matched replicate (2026-08-13,
  results/recipe-bf16-chat18k-c2rerun) REPRODUCED it: 5.88s (c=1 replicated
  1.34s exactly). It's real systematic bf16-arm behavior at c=2, not noise.
  Retroactively casts doubt on round one's "transient" read of fp8 c=2 (6.1s→
  2.9s) — noted, not re-litigated. HTML caption updated.
- Config correction (2026-08-13): cb-recipe blend server L1 is 60GB
  (LMCACHE_MAX_LOCAL_CPU_SIZE, live env), not 100GB as table first said.
- Both round-two figures/tables now 3 arms (fp8 green, bf16 blue #2a78d6, CB
  orange); × labels color-coded by opponent. Exec summary caveat resolved.
- fp8 arm can be restored with gptoss120b-recipe.yaml (currently bf16 pod live).

### Chat (chat18k): CacheBlend wins here too (UNEXPECTED — designed as near-tie)
- Both arms hit ~88% (baseline: `hit tokens: 15872` per request). Gap is the LOAD PATH:
  baseline = synchronous ~2.5GB bulk copy inside engine path (~0.5s, queues like a mini-prefill);
  CacheBlend = prefetch while Deferred + scatter into paged blocks (~1–3ms)
- TTFT p90: 3.8×/6.6×/2.6× at c=1/2/4, converging to 1.1× at c=32
- Throughput: CB plateaus ~15k tok/s (c=4), baseline reaches 13.7k at c=32 still climbing
- LIKELY CONFOUND: `LMCACHE_USE_LAYERWISE=False` (LMCache default; textually mirrored from
  cb-colo where it's inert). `True` pipelines retrieval layer-by-layer → layerwise re-run
  planned (`lmcache-chat18k-layerwise`), chat deltas marked PROVISIONAL in report

## Key files (all in ~/Desktop/benchmarks/)

- `cacheblend-rag-benchmark.html` — THE REPORT (688KB, self-contained, both figures embedded
  as base64). Config table (incl. layerwise row), both workload sections w/ dataset explainers,
  example record, metric definitions, caveats. Renamed from vllm-deployment-configs.html.
- `results/{lmcache-r85, cacheblend-r85, lmcache-chat18k, cacheblend-chat18k}/` — full aiperf
  artifacts per leg (c1..c32 dirs with .json summaries; inputs.json excluded). Also on PVC
  `hf-cache` at /opt/models/bench/results/.
- `plot_comparison.py` / `plot_chat_comparison.py` — regenerate figures+CSVs
  (rag-r85-comparison.{png,csv}, chat-18k-comparison.{png,csv}). Palette: blue #2a78d6
  baseline, orange #eb6834 CacheBlend; TTFT/ITL use p90; throughput = req/s × (ISL+OSL);
  Pareto x = OSL/request_latency (1000/ITL degenerates: decode ~25ms at all loads).
- `plot_2k_comparison.py` → rag-2k-comparison.{png,csv}. SAME panels/metrics as the
  r85 figure (user wants figure consistency across the report): TTFT p90, ITL p90,
  throughput/GPU, Pareto. Two legs only (green #1baf7a recipe, orange #eb6834 CB).
  Embedded in the HTML report (own "Round two" section) 2026-08-13.
- `results/{recipe-2k, cb-recipe-2k}/` — 2k-chunk RAG legs (c1..c32 + prewarm).
- `results/round2-tuned-cb-chat18k/` — round-two chat leg (cb-recipe arm);
  `plot_round2_chat_comparison.py` → round2-chat18k-comparison.{png,csv}.
- `gptoss120b-recipe-bf16.yaml` — bf16-KV recipe variant (single-flag ablation;
  same deployment name/endpoint, applying replaces the fp8 pod).
- `generate_blend_dataset.py` also produced `rag_2k.jsonl` (4000 req, 590MB),
  `rag_2k.answers.json`, `rag_2k.stats.json` (2048-tok chunks, ISL est ~31.5k,
  actual ~35k, hot pool 750 chunks).
- `ai-perf-rag.yaml` — RAG benchmark job (currently ENDPOINT=cb-colo/cacheblend-r85).
  Per-point aiperf invocation on DISJOINT dataset slices (aiperf restarts sampler per
  subprocess — zip sweep would replay prompts!); 400-req shared prewarm.
- `aiperf-chat.yaml` — chat benchmark job (currently ENDPOINT=cb-colo/cacheblend-chat18k).
  Per-point seeds 42+i (same RNG stream generates prefixes AND uniques — shared seed would
  replay → 100% hits); `--warmup-request-count 40` (deterministic, fills 8 prefixes).
  Warmup internally replays last 10 prompts (pool cycling) — unmeasured, harmless.
- `gptoss120b-recipe.yaml` — optimized-vllm arm, DRAFTED NOT APPLIED (needs freed GPU).
  Risk: SimpleCPUOffloadConnector may be dynamo-only (we call plain `vllm serve`) → if
  unknown-connector error, drop connector, then fp8 if needed; keep APC+chunked prefill.
- `gptoss120b-lmcache.yaml` — baseline arm manifest.
- `generate_blend_dataset.py`, `rag_r85.jsonl` (4000 req, also on PVC), `rag_r85.answers.json`
  (for future accuracy scoring — NOT yet done), `rag_r85.stats.json`.
- `ISSUE-cacheblend-idle-reaper.md` — bug writeup for Kosseila (see below).

## Gotchas / incidents (don't rediscover these)

1. **CacheBlend idle-reaper bug**: cb-colo silently loses caching after ~1h idle
   (`Reaped GPU instance`, then every lookup fails `No CB GPU context`, no client-visible
   error). Fix = pod restart. ALWAYS smoke-test before benchmarking cb-colo:
   send 2 identical requests, check `kubectl logs deploy/gptoss120b-cb-colo -c engine --since=2m | grep -c "No CB GPU context"` == 0.
   Post-restart pod heartbeats properly, may be fixed. Report: ISSUE-cacheblend-idle-reaper.md.
2. **Single-GPU rollout deadlock**: deployments were RollingUpdate; new pod Pending on GPU.
   cb-colo patched to Recreate. lmcache arm may still be RollingUpdate — check before restarts.
3. **aiperf MultiRunOrchestrator** runs each sweep point as isolated subprocess → sampler
   restarts at line 0 / RNG stream restarts. Both job yamls already engineered around this.
4. **hf-token-secret doesn't exist** in cacheblend-workload → keep `optional: true`.
5. Engine's `External prefix cache hit rate` counter misleading for CB (blend bypasses it);
   read `blend_v3` `match_probe`/`Retrieved pre-computed` lines instead.
6. Baseline retrieval logs: `LMCache hit tokens: N` per request.

## SCOPE DECISION (user, 2026-08-13): stop after bf16 documentation
Remaining work = (1) recipe-bf16-2k RAG sweep (RUNNING), (2) recipe-bf16-chat18k
chat sweep, (3) document bf16 results in HTML — bf16 is PART OF ROUND TWO (user decision):
add as a THIRD LINE to the round-two figures/tables (like round one's 3-leg
figures), not a new section; update the two "wins are lower bounds" caveats.
Then STOP. Explicitly descoped: accuracy scoring, P/D-disagg
round three, layerwise re-run, long-output test. (Accuracy remains listed as an
Astra adoption blocker in the exec summary — descoped from this eval, not from
the adoption criteria.)

## Where we left off / next steps (in discussed order)

0. **2k-chunk RAG results are in and reported** (2026-08-13): figure+CSV generated
   (`rag-2k-comparison.{png,csv}`) and embedded in `cacheblend-rag-benchmark.html`
   as its own "Round two" section (after Cross-workload takeaway). DONE.
1. **Optimized-vLLM (recipe) arm** — user's priority. Free GPU:
   `kubectl scale deploy/gptoss120b-cb-colo -n cacheblend-workload --replicas=0`
   → `kubectl apply -f gptoss120b-recipe.yaml` → watch startup for connector/fp8 issues →
   run BOTH sweeps against it: aiperf-chat.yaml (ENDPOINT=gptoss120b-recipe:8000,
   RUN_NAME=recipe-chat18k) and ai-perf-rag.yaml (RUN_NAME=recipe-r85) →
   three-line figures per workload → update HTML.
   Expected: chat = recipe's best case (prefixes GPU-resident, zero transfer);
   RAG = recipe compute-bound ~5–6k tok/s, CB should clearly win.
2. **Layerwise re-run** (demoted to footnote but still planned): set
   `LMCACHE_USE_LAYERWISE=True` on gptoss120b-lmcache, restart, re-run chat job as
   `lmcache-chat18k-layerwise`. Answers "was the chat gap a config artifact?" —
   HTML marks chat deltas provisional pending this.
3. **Accuracy scoring** (mentioned in report caveats): compare answers leg-vs-leg using
   rag_r85.answers.json. Not started.
4. Report Kosseila: idle-reaper issue file. Report Marc/LMCache: layerwise default finding
   (after #2 confirms).

## Benchmark protocol reminders

- One leg at a time (arms share host RAM bandwidth/PCIe — concurrent legs contaminate TTFT).
- Delete job between legs (`kubectl delete job aiperf-rag|aiperf-chat -n cacheblend-workload`).
- Monitor pattern: `kubectl logs -f job/<name> | grep --line-buffered "=== \|DONE\|FATAL\|Error"`.
- Progress: newest log on PVC via lmcache pod:
  `kubectl exec deploy/gptoss120b-lmcache -n cacheblend-workload -- sh -c 'f=$(ls -t /opt/models/bench/results/<RUN_NAME>/*.log | head -1); tail -c 400 "$f"' | tr '\r' '\n' | grep Profiling | tail -1`
- After each leg: tar results (exclude inputs.json) from PVC → results/, rebuild figure,
  re-embed base64 into HTML (embed step in session history; figures are NOT auto-embedded).
- request_throughput / *_token_throughput in aiperf JSONs are run-level scalars under "avg"
  (no percentiles); TTFT/ITL have full distributions.
