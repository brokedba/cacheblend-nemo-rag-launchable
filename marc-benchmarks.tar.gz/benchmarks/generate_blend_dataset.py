#!/usr/bin/env python3
"""Generate a RAG-shaped AIPerf dataset from 2WikiMultihopQA (or HotpotQA-style parquet).

Each request = [2 supporting docs for the question] + [N hot chunks sampled from a
shared pool], all shuffled, + the question. Hot chunks recur across requests at
different positions -> non-prefix reuse (CacheBlend's target pattern). Prefix
caching cannot exploit it; content-addressed caching can.

Outputs:
  <out>.jsonl        AIPerf custom dataset (--custom-dataset-type single_turn)
  <out>.answers.json sidecar: [{id, question, answer}] for later accuracy scoring
  <out>.stats.json   dataset statistics (reuse ratio, ISL estimate, pool KV size)

Token counts are estimated at 0.75 words/token (documented approximation);
use aiperf --use-server-token-count for exact ISL at run time.
"""
import argparse, json, random, sys, urllib.request
from pathlib import Path

DEFAULT_PARQUET_URL = "https://huggingface.co/datasets/xanhho/2WikiMultihopQA/resolve/main/dev.parquet"
WORDS_PER_TOKEN = 0.75          # approximation for sizing; server reports true counts
KV_BYTES_PER_TOKEN = 160 * 1024  # Llama-3.3-70B, fp8 KV cache


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--parquet", default=None, help="local parquet path (downloads 2WikiMQA dev split if omitted)")
    p.add_argument("--num-requests", type=int, default=2000)
    p.add_argument("--chunks-per-request", type=int, default=16, help="total chunks incl. supporting docs")
    p.add_argument("--reuse-ratio", type=float, default=None,
                   help="target fraction of chunks from the hot pool (overrides --hot-chunks)")
    p.add_argument("--hot-chunks", type=int, default=None,
                   help="hot-pool chunks per request (default: chunks-per-request - #supporting)")
    p.add_argument("--chunk-tokens", type=int, default=1024, help="approx tokens per chunk (multiple of 256 recommended)")
    p.add_argument("--hot-pool-size", type=int, default=1500,
                   help="number of chunks in the shared hot pool (sets cache working-set size)")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--out", default="rag_dataset", help="output file prefix")
    return p.parse_args()


def load_rows(parquet_path):
    import pyarrow.parquet as pq
    t = pq.read_table(parquet_path, columns=["_id", "question", "context", "supporting_facts", "answer"])
    for i in range(t.num_rows):
        yield {c: t.column(c)[i].as_py() for c in t.column_names}


def main():
    a = parse_args()
    rng = random.Random(a.seed)

    parquet = a.parquet
    if not parquet:
        parquet = "/tmp/2wiki_dev.parquet"
        if not Path(parquet).exists():
            print(f"downloading dev split -> {parquet}", file=sys.stderr)
            urllib.request.urlretrieve(DEFAULT_PARQUET_URL, parquet)

    rows = list(load_rows(parquet))
    rng.shuffle(rows)
    if a.num_requests > len(rows):
        sys.exit(f"ERROR: requested {a.num_requests} requests but dataset has only {len(rows)} unique questions")

    # ---- paragraph pool (deduped by title) --------------------------------
    paragraphs = {}   # title -> text
    for r in rows:
        for title, sents in json.loads(r["context"]):
            paragraphs.setdefault(title, " ".join(sents))

    # ---- merge paragraphs into ~chunk_tokens chunks ------------------------
    # First hot_pool_size chunks form the HOT pool (reused across requests);
    # the remainder form the COLD reserve (each used ~once -> fresh tokens).
    chunk_words = int(a.chunk_tokens * WORDS_PER_TOKEN)
    titles = sorted(paragraphs)
    rng.shuffle(titles)
    all_chunks, buf, buf_words = [], [], 0
    for t in titles:
        buf.append(f"[{t}]\n{paragraphs[t]}")
        buf_words += len(paragraphs[t].split())
        if buf_words >= chunk_words:
            all_chunks.append("\n\n".join(buf))
            buf, buf_words = [], 0
    hot_pool = all_chunks[: a.hot_pool_size]
    cold_reserve = all_chunks[a.hot_pool_size:]
    if len(hot_pool) < a.hot_pool_size:
        print(f"WARN: pool exhausted at {len(hot_pool)} chunks (< {a.hot_pool_size})", file=sys.stderr)

    # ---- per-request hot/cold split ----------------------------------------
    # reuse_ratio ~= fraction of full-size chunks that are hot (reused).
    # 2 small supporting docs ride along for answerability (counted as fresh).
    n_support = 2
    n_body = a.chunks_per_request - n_support  # full-size chunks per request
    if a.reuse_ratio is not None:
        n_hot = max(0, min(n_body, round(a.reuse_ratio * n_body)))
    elif a.hot_chunks is not None:
        n_hot = min(a.hot_chunks, n_body)
    else:
        n_hot = n_body
    n_cold = n_body - n_hot
    cold_needed = a.num_requests * n_cold
    if n_cold and cold_needed > len(cold_reserve):
        print(f"WARN: need {cold_needed} cold chunks, reserve has {len(cold_reserve)} ? "
              f"cold chunks will cycle (slight unintended reuse, noted in stats)", file=sys.stderr)
    cold_iter_idx = 0
    def next_cold():
        nonlocal cold_iter_idx
        c = cold_reserve[cold_iter_idx % len(cold_reserve)]
        cold_iter_idx += 1
        return c

    # ---- generate ----------------------------------------------------------
    out_jsonl = Path(f"{a.out}.jsonl")
    answers, word_counts, hot_words_total, all_words_total = [], [], 0, 0
    with out_jsonl.open("w") as f:
        for r in rows[: a.num_requests]:
            # dict.fromkeys = order-preserving dedupe (a set here would break
            # determinism: set iteration order varies with PYTHONHASHSEED)
            support_titles = list(dict.fromkeys(sf[0] for sf in json.loads(r["supporting_facts"])))[:n_support]
            support = [f"[{t}]\n{paragraphs.get(t, '')}" for t in support_titles]
            hot = rng.sample(hot_pool, n_hot)
            cold = [next_cold() for _ in range(n_cold)]
            chunks = support + hot + cold
            rng.shuffle(chunks)
            prompt = ("Use the following documents to answer the question.\n\n"
                      + "\n\n".join(chunks)
                      + f"\n\nQuestion: {r['question']}\nAnswer concisely:")
            f.write(json.dumps({"text": prompt}) + "\n")
            answers.append({"id": r["_id"], "question": r["question"], "answer": r["answer"]})
            w = len(prompt.split())
            word_counts.append(w)
            hot_words_total += sum(len(c.split()) for c in hot)
            all_words_total += w

    Path(f"{a.out}.answers.json").write_text(json.dumps(answers, indent=1))

    # ---- stats -------------------------------------------------------------
    mean_words = sum(word_counts) / len(word_counts)
    est_isl = int(mean_words / WORDS_PER_TOKEN)
    pool_words = sum(len(c.split()) for c in hot_pool)
    pool_tokens = int(pool_words / WORDS_PER_TOKEN)
    stats = {
        "num_requests": a.num_requests,
        "chunks_per_request": a.chunks_per_request,
        "hot_chunks_per_request": n_hot,
        "cold_chunks_per_request": n_cold,
        "cold_reserve_chunks": len(cold_reserve),
        "cold_chunks_cycled": bool(n_cold and a.num_requests * n_cold > len(cold_reserve)),
        "supporting_chunks_per_request": n_support,
        "token_reuse_ratio_est": round(hot_words_total / all_words_total, 3),
        "chunk_tokens_target": a.chunk_tokens,
        "est_mean_isl_tokens": est_isl,
        "hot_pool_chunks": len(hot_pool),
        "hot_pool_tokens_est": pool_tokens,
        "hot_pool_kv_gb_est_llama70b_fp8": round(pool_tokens * KV_BYTES_PER_TOKEN / 2**30, 1),
        "seed": a.seed,
    }
    Path(f"{a.out}.stats.json").write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
