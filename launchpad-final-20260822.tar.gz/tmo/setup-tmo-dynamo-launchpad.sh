#!/bin/bash
###############################################################################
# setup-tmo-dynamo-launchpad.sh — TMO LMCache engine + Dynamo DGD on Launchpad
# OpenShift. NO CACHEBLEND. Every phase is GATED. Idempotent.
#
# Source of truth: https://docs.tensormesh.ai/operator/integrations/dynamo
#
# MEASURED ON THE BOX 2026-08-21:
#   vllm-runtime:1.3.0 -> lmcache 0.4.6                  (will NOT pair with 0.5.2)
#   vllm-runtime:1.4.0 -> lmcache 0.5.2 + vLLM 0.26.0    (exact pair for chart 0.5.2)
#   1.4.0 is already cached on try-70986-gpu01. Operator is still 1.3.0; DGD CRD
#   serves v1alpha1 (storage) + v1beta1 — the manifest uses v1beta1, as NVIDIA's
#   own gpt-oss recipe does.
#
# WHAT CHANGES vs the CacheBlend install (same Helm release, values flipped):
#   engine.enabled=true / cacheBlend.enabled=false / webhook.enabled=false
#   (DGD workers set command:, and the webhook skips those — nothing to inject)
#
# REUSED DELIBERATELY: ns cacheblend-workload · PVC hf-cache (61GB of weights
#   already present) · SA tensormesh-operator-engine-privileged (SCC-bound)
#
# OPENSHIFT NOTE the doc omits: the worker needs hostIPC:true AND runAsUser:0.
#   Both exceed restricted-v2 -> privileged SA; PHASE 7 dry-run-admits that shape.
#
# Credentials — PROMPTS for anything not exported (silent read, no history).
# Optional: CHART_VERSION=0.5.2 STACK_TAG=v0.5.2 NS=cacheblend-workload L1_GB=100
#           SKIP_DGD=1  DGD_FILE=/path/to/manifest.yaml
###############################################################################
set -eu   # NOT pipefail: grep -q / head close pipes early -> SIGPIPE(141)

ask_secret() {
  local var=$1 prompt=$2 val=""
  [ -n "${!var:-}" ] && return 0
  [ -t 1 ] || [ -e /dev/tty ] || { echo "FATAL: $var unset and no TTY" >&2; exit 1; }
  while [ -z "$val" ]; do
    printf '%s' "$prompt" > /dev/tty
    IFS= read -rs val < /dev/tty
    printf '\n' > /dev/tty
  done
  export "$var=$val"
}
ask_plain() {
  local var=$1 prompt=$2 val=""
  [ -n "${!var:-}" ] && return 0
  [ -e /dev/tty ] || { echo "FATAL: $var unset and no TTY" >&2; exit 1; }
  while [ -z "$val" ]; do
    printf '%s' "$prompt" > /dev/tty
    IFS= read -r val < /dev/tty
  done
  export "$var=$val"
}

ask_plain  TMO_GHCR_USER  "GHCR username: "
ask_secret TMO_GHCR_TOKEN "GHCR read:packages token (chart): "

CHART_VERSION="${CHART_VERSION:-0.5.2}"
STACK_TAG="${STACK_TAG:-v0.5.2}"      # = lmcache in vllm-runtime:1.4.0
NS_OP="${NS_OP:-tensormesh-operator}"
# engine and DGD workers MUST share a namespace — the worker reads the engine's
# -connection ConfigMap, and ConfigMaps do not cross namespaces.
NS="${NS:-cacheblend-workload}"
ENGINE_NAME="${ENGINE_NAME:-tensormesh-lmcache}"
L1_GB="${L1_GB:-100}"
SA="${SA:-tensormesh-operator-engine-privileged}"
MODEL_PVC="${MODEL_PVC:-hf-cache}"
MODEL_PVC_SIZE="${MODEL_PVC_SIZE:-120Gi}"
RUNTIME_IMAGE="${RUNTIME_IMAGE:-nvcr.io/nvidia/ai-dynamo/vllm-runtime:1.4.0}"

WORKDIR="$HOME/tmo-dynamo-setup"; mkdir -p "$WORKDIR"
exec > >(tee -a "$WORKDIR/setup.log") 2>&1
echo "=== setup start $(date -u +%FT%TZ) — chart $CHART_VERSION / engine $STACK_TAG / ns $NS ==="

step() { printf '\n############ %s ############\n' "$*"; }
fail() { echo "FATAL: $*" >&2; exit 1; }
warn() { echo "WARN: $*" >&2; }
poll() {
  local desc=$1 tries=$2 slp=$3; shift 3
  local i=1
  while [ "$i" -le "$tries" ]; do
    if "$@" >/dev/null 2>&1; then echo "GATE OK: $desc"; return 0; fi
    echo "  ...waiting ($i/$tries): $desc"; sleep "$slp"; i=$((i+1))
  done
  fail "gate never passed: $desc"
}

############################################################
step "PHASE 0 — tooling, cluster, free GPUs"
############################################################
for c in kubectl helm; do command -v "$c" >/dev/null || fail "$c not on PATH"; done
kubectl get ns >/dev/null 2>&1 || fail "not logged into the cluster"
GPUS=$(kubectl get nodes -l nvidia.com/gpu.present=true \
  -o jsonpath='{range .items[*]}{.metadata.name}={.status.allocatable.nvidia\.com/gpu} {end}')
[ -n "$GPUS" ] || fail "no GPU nodes"
echo "GPU nodes: $GPUS"
NODE=$(kubectl get nodes -l nvidia.com/gpu.present=true -o name | head -1 | cut -d/ -f2)
echo "--- GPUs allocated on $NODE (the DGD worker needs one free) ---"
kubectl describe node "$NODE" | sed -n '/Allocated resources/,/Events/p' | grep -E 'nvidia.com/gpu|Resource' || true
echo "If 2 of 2 are taken: kubectl -n $NS scale deploy --all --replicas=0"

############################################################
step "PHASE 1 — Dynamo operator + DGD CRD survey (report only)"
############################################################
kubectl get deploy -A -o jsonpath='{range .items[*]}{.metadata.namespace}{"/"}{.metadata.name}{" "}{.spec.template.spec.containers[*].image}{"\n"}{end}' \
  | grep -i dynamo || warn "no dynamo operator deployment found"
kubectl get crd dynamographdeployments.nvidia.com \
  -o jsonpath='{range .spec.versions[*]}{.name}{" served="}{.served}{" storage="}{.storage}{"\n"}{end}' \
  || warn "DGD CRD not found"

############################################################
step "PHASE 2 — lmcache version in the worker image (THE version gate)"
############################################################
kubectl get ns "$NS" >/dev/null 2>&1 || kubectl create ns "$NS"
kubectl -n "$NS" delete pod lmc-probe --ignore-not-found >/dev/null 2>&1 || true
kubectl -n "$NS" run lmc-probe --restart=Never --image="$RUNTIME_IMAGE" \
  --command -- python3 -c 'import lmcache, vllm; print("PROBE lmcache", lmcache.__version__, "vllm", vllm.__version__)' >/dev/null 2>&1 \
  && kubectl -n "$NS" wait --for=jsonpath='{.status.phase}'=Succeeded pod/lmc-probe --timeout=600s || warn "probe did not complete"
kubectl -n "$NS" logs lmc-probe 2>/dev/null | grep PROBE || warn "no probe output"
kubectl -n "$NS" delete pod lmc-probe --ignore-not-found >/dev/null 2>&1 || true
echo "Expect lmcache 0.5.2 to match engine $STACK_TAG. 0.4.x means the 1.3.0"
echo "image — fix RUNTIME_IMAGE, do NOT downgrade the engine."

############################################################
step "PHASE 3 — namespace, PSA, privileged SA, model PVC"
############################################################
kubectl get ns "$NS_OP" >/dev/null 2>&1 || kubectl create ns "$NS_OP"
kubectl label ns "$NS" security.openshift.io/scc.podSecurityLabelSync=false --overwrite
for ch in enforce audit warn; do
  kubectl label ns "$NS" "pod-security.kubernetes.io/$ch=privileged" --overwrite
done
LBL=$(kubectl get ns "$NS" -o jsonpath='{.metadata.labels.pod-security\.kubernetes\.io/enforce}')
[ "$LBL" = "privileged" ] || fail "$NS PSA enforce label is '$LBL'"

kubectl -n "$NS" get sa "$SA" >/dev/null 2>&1 || kubectl -n "$NS" create sa "$SA"
kubectl -n "$NS" create rolebinding "${SA}-scc" \
  --clusterrole=system:openshift:scc:privileged \
  --serviceaccount="$NS:$SA" --dry-run=client -o yaml | kubectl apply -f -

# HELM ADOPTION — required, not cosmetic. With engine.namespace set, the chart
# TEMPLATES this same SA into $NS, and helm refuses to take over a resource that
# lacks its ownership metadata:
#   Error: UPGRADE FAILED: ServiceAccount "..." exists and cannot be imported
#   into the current release: missing key "app.kubernetes.io/managed-by"
# The SA is here because setup-tmo-cb-launchpad.sh created it by hand — the
# CacheBlend path put the chart's own copy in the RELEASE namespace instead.
# (Chart inconsistency worth reporting: engine.namespace and cacheBlend.namespace
# place the SA differently.) Stamping the metadata is idempotent.
for r in "sa/$SA" "rolebinding/${SA}-scc"; do
  kubectl -n "$NS" label    "$r" app.kubernetes.io/managed-by=Helm --overwrite >/dev/null 2>&1 || true
  kubectl -n "$NS" annotate "$r" meta.helm.sh/release-name=tensormesh-operator \
                                 meta.helm.sh/release-namespace="$NS_OP" --overwrite >/dev/null 2>&1 || true
done
echo "adopted into Helm: $SA + ${SA}-scc"

if kubectl -n "$NS" get pvc "$MODEL_PVC" >/dev/null 2>&1; then
  echo "reusing existing PVC $MODEL_PVC (weights should already be present)"
else
  SC=""; AM="ReadWriteMany"
  if kubectl get sc nfs-client >/dev/null 2>&1; then SC="nfs-client"; else
    SC=$(kubectl get sc -o jsonpath='{range .items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")]}{.metadata.name}{end}' 2>/dev/null || true)
    [ -n "$SC" ] && AM="ReadWriteOnce"
  fi
  [ -n "$SC" ] || fail "no StorageClass — the worker needs a model cache PVC"
  kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: $MODEL_PVC, namespace: $NS }
spec:
  accessModes: [$AM]
  storageClassName: $SC
  resources: { requests: { storage: $MODEL_PVC_SIZE } }
EOF
  echo "created PVC $MODEL_PVC ($AM on $SC) — expect a ~65GB first download"
fi

############################################################
step "PHASE 4 — TMO chart: LMCache engine only (removes CacheBlend)"
############################################################
cat > "$WORKDIR/values-dynamo-launchpad.yaml" <<EOF
crds: { enabled: true }
fullnameOverride: tensormesh-operator

openshift: { enabled: true }

webhook:     { enabled: false }
cacheBlend:  { enabled: false }
coordinator: { enabled: false }
tests:       { enabled: false }

engine:
  enabled: true
  name: $ENGINE_NAME
  namespace: $NS
  spec:
    l1: { sizeGB: $L1_GB }
    server: { chunkSize: 256 }
    image:
      repository: lmcache/vllm-openai
      tag: $STACK_TAG
      pullPolicy: IfNotPresent
EOF
echo "--- values ---"; cat "$WORKDIR/values-dynamo-launchpad.yaml"

# Skip helm entirely if the engine already exists and is Running. The engine CR is
# a Helm HOOK (hook-delete-policy: before-hook-creation), so every upgrade DELETES
# and recreates it — dropping the cache and orphaning worker registrations. Cluster
# state is the guard, not a state file. Force a real upgrade with FORCE_HELM=1
# (needed when changing chart values/version).
if [ "${FORCE_HELM:-0}" != "1" ] && [ "$(kubectl -n "$NS" get lmcacheengine "$ENGINE_NAME" -o jsonpath='{.status.phase}' 2>/dev/null)" = "Running" ]; then
  echo "engine '$ENGINE_NAME' already Running — SKIPPING helm upgrade (FORCE_HELM=1 to override)"
else
helm registry login ghcr.io -u "$TMO_GHCR_USER" --password-stdin <<<"$TMO_GHCR_TOKEN"
helm upgrade --install tensormesh-operator \
  oci://ghcr.io/tensormesh-production/charts/tensormesh-operator \
  --version "$CHART_VERSION" -n "$NS_OP" --create-namespace \
  -f "$WORKDIR/values-dynamo-launchpad.yaml" --wait --timeout 15m
fi
kubectl -n "$NS_OP" rollout status deploy/tensormesh-operator --timeout=300s

############################################################
step "PHASE 5 — engine reconciled + connection ConfigMap"
############################################################
poll "LMCacheEngine CR '$ENGINE_NAME' exists" 60 3 \
  kubectl -n "$NS" get lmcacheengine "$ENGINE_NAME"
# Deterministic: the operator publishes <CR name>-connection. Do NOT glob for
# '-connection' — a stale CacheBlendEngine leaves its own behind and you would
# wire the DGD to the blend connector (hit 2026-08-21).
CM="${ENGINE_NAME}-connection"
poll "connection ConfigMap $CM published" 90 5 \
  kubectl -n "$NS" get configmap "$CM"

echo "--- keys ---"
echo "--- kv-transfer-config.json ---"
CONN=$(kubectl -n "$NS" get configmap "$CM" -o go-template='{{index .data "kv-transfer-config.json"}}' 2>/dev/null || true)
[ -n "$CONN" ] || fail "$CM has no kv-transfer-config.json key"
echo "$CONN"
case "$CONN" in
  *CBKVConnector*) fail "$CM is the CACHEBLEND connector — wrong engine for this track" ;;
  *) echo "connector looks like the LMCache path OK" ;;
esac

# Helm does NOT prune the CacheBlendEngine CR when cacheBlend.enabled flips to
# false (observed 2026-08-21: the 14-day-old CR kept running with its 200GB L1).
if kubectl -n "$NS" get cacheblendengine -o name 2>/dev/null | grep -q .; then
  warn "a CacheBlendEngine CR is STILL running — it holds its L1 RAM and publishes"
  warn "a competing -connection ConfigMap. Remove it:"
  kubectl -n "$NS" get cacheblendengine -o name | sed "s|^|  kubectl -n $NS delete |"
fi
echo "CONFIGMAP_NAME=$CM   <- must match the DGD's configMapKeyRef.name"

############################################################
step "PHASE 6 — engine pod Ready on CUDA"
############################################################
poll "engine pod exists" 60 5 \
  sh -c "kubectl -n '$NS' get pod -l app.kubernetes.io/component=cache-engine -o name | grep -q ."
ENG_POD=$(kubectl -n "$NS" get pod -l app.kubernetes.io/component=cache-engine -o name | head -1)
kubectl -n "$NS" wait --for=condition=Ready "$ENG_POD" --timeout=900s
# version-tolerant: v0.5.3 dropped "Using backend: lmcache.c_ops". Match a SET of
# CUDA tells; fail only on an explicit CPU stub. --all-containers is load-bearing.
L=$(kubectl -n "$NS" logs "$ENG_POD" --all-containers=true --tail=-1 2>/dev/null || true)
if echo "$L" | grep -qE 'StubCPUDevice|Using backend: lmcache\.cpu'; then
  fail "engine came up on the CPU stub"
elif echo "$L" | grep -qE 'Using backend: lmcache\.c_ops|platform\.cuda|torch_device_type=cuda|CudaPinMemoryBackend'; then
  echo "engine on CUDA OK"
else
  warn "no backend evidence; engine is Ready — continuing"
fi

############################################################
step "PHASE 7 — SCC probe: hostIPC + runAsUser 0 together"
############################################################
kubectl -n "$NS" apply --dry-run=server -f - <<EOF
apiVersion: v1
kind: Pod
metadata: { name: scc-probe }
spec:
  serviceAccountName: $SA
  hostIPC: true
  securityContext: { runAsUser: 0 }
  containers: [{ name: p, image: registry.access.redhat.com/ubi9/ubi-minimal, command: ["sleep","1"] }]
EOF
echo "hostIPC + runAsUser 0 admission OK"

############################################################
step "PHASE 8 — apply the DGD worker (skip with SKIP_DGD=1)"
############################################################
DGD_FILE="${DGD_FILE:-$(dirname "$0")/gptoss120b-dynamo-lmcache.yaml}"
if [ "${SKIP_DGD:-0}" = "1" ]; then
  echo "SKIP_DGD=1 — not applying"
elif [ ! -f "$DGD_FILE" ]; then
  warn "no DGD manifest at $DGD_FILE — apply it yourself"
else
  # values this script owns; editing them by hand in two places is how they drift
  # (change engine.name and the worker silently references the old ConfigMap).
  RENDERED="$WORKDIR/$(basename "$DGD_FILE" .yaml)-rendered.yaml"
  sed -e "s|name: default-connection|name: ${ENGINE_NAME}-connection|" -e "s|namespace: cacheblend-workload|namespace: ${NS}|" -e "s|image: nvcr.io/nvidia/ai-dynamo/vllm-runtime:[^ ]*|image: ${RUNTIME_IMAGE}|" -e "s|claimName: hf-cache|claimName: ${MODEL_PVC}|" "$DGD_FILE" > "$RENDERED"
  echo "--- rendered DGD (diff vs source) ---"
  diff "$DGD_FILE" "$RENDERED" || true
  grep -q "name: ${ENGINE_NAME}-connection" "$RENDERED" || fail "render failed: no ${ENGINE_NAME}-connection reference in $RENDERED"
  # SCC for the operator's OWN SA, BEFORE the apply. The operator runs DGD pods as
  # <dgd>-k8s-service-discovery; without the privileged SCC the frontend cannot create
  # any pod (operator injects fsGroup 1000, rejected by restricted-v2) and the worker
  # cannot have hostIPC + runAsUser 0.
  DGD_NAME=$(kubectl apply --dry-run=client -f "$RENDERED" -o jsonpath='{.metadata.name}')
  [ -n "$DGD_NAME" ] || fail "could not read metadata.name from $RENDERED"
  DGD_SA="${DGD_NAME}-k8s-service-discovery"
  kubectl -n "$NS" get sa "$DGD_SA" >/dev/null 2>&1 || kubectl -n "$NS" create sa "$DGD_SA"
  kubectl -n "$NS" create rolebinding "${DGD_SA}-scc" --clusterrole=system:openshift:scc:privileged --serviceaccount="$NS:$DGD_SA" --dry-run=client -o yaml | kubectl apply -f -
  echo "privileged SCC granted to $DGD_SA (pre-created, before the DGD)"
  kubectl apply -f "$RENDERED"
  DGD=$(kubectl -n "$NS" get dynamographdeployment -o name | tail -1)
  DGD_NAME=$(basename "$DGD")
  echo "applied: $DGD"
  # No guessed label selectors — the operator names pods after the DGD.
  poll "pods created for $DGD_NAME" 60 5 \
    sh -c "kubectl -n '$NS' get pod -o name | grep -q '$DGD_NAME'"
  echo "--- pods ---"; kubectl -n "$NS" get pod -o wide
  echo "Model load takes minutes. Watch: kubectl -n $NS get pod -w"
  echo "If the worker CrashLoopBackOffs, read WHERE the traceback is:"
  echo "  ai_dynamo/*  -> operator 1.3.0 vs image 1.4.0 mismatch (upgrade needed)"
  echo "  vllm|lmcache -> config problem in the manifest"
fi

############################################################
############################################################
step "PHASE 9 — smoke: completion served AND cache genuinely in the path"
############################################################
if [ "${SKIP_DGD:-0}" = "1" ]; then
  echo "SKIP_DGD=1 — nothing to smoke"
else
  FRONT_SVC="${DGD_NAME}-frontend"
  # If the engine pod started AFTER the worker, the worker's lookup path is orphaned
  # (proven 2026-08-22: it re-registers but LOOKUP times out 300s -> "Marking server
  # as unhealthy" -> serves cacheless, silently). Restart the worker in that case.
  ENG_START=$(kubectl -n "$NS" get pod -l app.kubernetes.io/component=cache-engine -o jsonpath='{.items[0].status.startTime}' 2>/dev/null)
  AGG_DEPLOY=$(kubectl -n "$NS" get deploy -o name | grep -- "-agg-" | head -1 | cut -d/ -f2)
  AGG_START=$(kubectl -n "$NS" get pod -l nvidia.com/dynamo-component-type=worker -o jsonpath='{.items[0].status.startTime}' 2>/dev/null)
  if [ -n "$ENG_START" ] && [ -n "$AGG_START" ] && [ "$ENG_START" \> "$AGG_START" ]; then
    echo "engine ($ENG_START) is younger than worker ($AGG_START) — worker's cache path is orphaned; restarting worker"
    kubectl -n "$NS" scale deploy "$AGG_DEPLOY" --replicas=0; sleep 10
    kubectl -n "$NS" scale deploy "$AGG_DEPLOY" --replicas=1
    kubectl -n "$NS" rollout status deploy "$AGG_DEPLOY" --timeout=1800s
  fi
  poll "worker Ready" 120 15 \
    sh -c "kubectl -n '$NS' get pod -l nvidia.com/dynamo-component-type=worker -o jsonpath='{.items[*].status.containerStatuses[*].ready}' | grep -q true"
  # port-forward makes this the localhost case — same test as the Brev/Nebius scripts
  kubectl -n "$NS" port-forward "svc/$FRONT_SVC" 18000:8000 >/dev/null 2>&1 &
  PF=$!; sleep 3
  curl -sf "http://localhost:18000/v1/models" | grep -q "gpt-oss-120b" \
    && echo "PASS: model registered" || { kill $PF 2>/dev/null; fail "model not registered on $FRONT_SVC"; }
  # random prefix -> first send STORES fresh, second must RETRIEVE (APC is off).
  # ~2800 tokens crosses chunk_size 256; max_tokens leaves reasoning headroom.
  LONG_PROMPT=$(python3 -c "import random; print(random.randint(0,10**9), 'The quick brown fox jumps over the lazy dog. '*300)")
  for i in 1 2; do
    curl -sf "http://localhost:18000/v1/completions" -H 'Content-Type: application/json' \
      -d "{\"model\":\"openai/gpt-oss-120b\",\"prompt\":\"$LONG_PROMPT\",\"max_tokens\":128}" >/dev/null \
      || { kill $PF 2>/dev/null; fail "completion $i failed"; }
  done
  kill $PF 2>/dev/null
  echo "PASS: completions served"
  ENG_POD=$(kubectl -n "$NS" get pod -l app.kubernetes.io/component=cache-engine -o name | head -1)
  L=$(kubectl -n "$NS" logs "$ENG_POD" --all-containers=true --since=3m 2>/dev/null | grep -E "Stored|Retrieved" | tail -4)
  echo "$L"
  echo "$L" | grep -q "Stored"    || fail "engine never STORED — connector not in the path"
  echo "$L" | grep -q "Retrieved" || fail "engine never RETRIEVED — repeat prompt not served from cache"
  echo "PASS: LMCache stored AND retrieved — cache is genuinely in the path"
fi

step "READY"
############################################################
cat > "$WORKDIR/READY.txt" <<EOF
=== TMO LMCache engine + Dynamo DGD $(date -u +%FT%TZ) ===
namespace            : $NS
privileged SA        : $SA
connection ConfigMap : $CM
chart / engine image : $CHART_VERSION / $STACK_TAG
worker image         : $RUNTIME_IMAGE   (lmcache 0.5.2, vLLM 0.26.0)
model PVC            : $MODEL_PVC

VERIFY LMCACHE IS ACTUALLY IN THE PATH:
  # args reached vLLM — enable_prefix_caching must be False for the wiring test
  kubectl -n $NS logs deploy/<worker> | grep -m1 "non-default args"
  # connector loaded
  kubectl -n $NS logs deploy/<worker> | grep -iE "LMCacheMPConnector|kv_connector"
  # engine stores then retrieves: send the SAME prompt twice
  kubectl -n $NS logs $ENG_POD --all-containers=true --tail=100 | grep -E "Stored|Retrieved"

TEARDOWN: helm -n $NS_OP uninstall tensormesh-operator
EOF
cat "$WORKDIR/READY.txt"
