#!/bin/bash
###############################################################################
# setup-tmo-cb-launchpad.sh — ONE-SHOT: TMO CacheBlend (vLLM track) on Launchpad
# OpenShift. Every phase is GATED: it polls/verifies before the next starts, and
# fails loudly with the reason. Idempotent — re-run after a failure and completed
# phases fast-forward.
#
# Modeled on setup-tmo-cb-cu13-launch.sh (Brev), minus the driver dance (Launchpad
# node is already CUDA 13 / driver 580 — verified 2026-08-06) and plus OpenShift
# SCC handling per docs.tensormesh.ai/operator/installation/openshift.
#
# ---------------------------------------------------------------------------
# REQUIREMENTS — confirmed in PREP (runbook Step 0), NOT re-checked here:
#   * cluster-admin-ish rights: can create rolebindings (chart binds the SCC)
#   * privileged SCC allows hostIPC AND privileged  (allowHostIPC=true,
#     allowPrivilegedContainer=true) — the webhook injects hostIPC
#   * no admission policy engine vetoing privileged pods (Gatekeeper/Kyverno)
#   * a StorageClass EXISTS and its backing store has ENOUGH FREE SPACE:
#     >= 80GB for gpt-oss-120b (MXFP4 weights ~65GB + HF blob overhead), shared
#     by both arms. NOTE: with nfs-subdir-external-provisioner the PVC's
#     requested size is NOT enforced and it binds regardless — Step 0's df probe
#     is what actually confirms capacity. Without a StorageClass this script
#     falls back to emptyDir and the weights re-download on every pod recreate.
#   * GPU node present with nvidia.com/gpu allocatable
# ---------------------------------------------------------------------------
#
# Credentials — the script PROMPTS for anything not already exported (silent
# read, so nothing lands in shell history: safe on a shared Guacamole/upterm
# terminal). Export them instead only for unattended/CI runs.
#   CB_PLUGIN_TOKEN   read-only Docker Hub token for tensormesh/cacheblend-plugin
#   TMO_GHCR_TOKEN    GHCR read:packages token for the chart
#   TMO_GHCR_USER     GHCR username (not secret)
#   HF_TOKEN          OPTIONAL — gpt-oss-120b is ungated; set only for authed pulls
# Optional:
#   CB_PLUGIN_USER=tensormesh  CHART_VERSION=0.5.2  STACK_TAG=v0.5.3
#   NS_OP=tensormesh-operator  NS_WL=cacheblend-workload
#   SKIP_BASELINE=0            set 1 to install only the CB arm
#
# Usage (interactive — prompts for the 3 required credentials):
#   bash setup-tmo-cb-launchpad.sh
# Usage (unattended):
#   export CB_PLUGIN_TOKEN=... TMO_GHCR_TOKEN=... TMO_GHCR_USER=...   # HF_TOKEN optional
#   bash setup-tmo-cb-launchpad.sh
###############################################################################
set -eu   # NOT pipefail: grep -q / head close pipes early -> SIGPIPE(141) would kill us

# --- credentials -----------------------------------------------------------
# Pre-exported env wins (Brev/CI style). Otherwise we PROMPT: on a shared
# terminal (Guacamole/upterm) an `export ...` line is visible to anyone who runs
# `history`, while a silent read never lands in history, scrollback, or the log.
# Prompts + reads go straight to /dev/tty so they survive the stdout->tee
# redirection below and work even if stdin is piped.
ask_secret() {   # ask_secret VAR "Prompt: "
  local var=$1 prompt=$2 val=""
  [ -n "${!var:-}" ] && return 0
  [ -t 1 ] || [ -e /dev/tty ] || { echo "FATAL: $var unset and no TTY to prompt on — export it first" >&2; exit 1; }
  while [ -z "$val" ]; do
    printf '%s' "$prompt" > /dev/tty
    IFS= read -rs val < /dev/tty
    printf '\n' > /dev/tty
  done
  export "$var=$val"
}
ask_plain() {    # ask_plain VAR "Prompt: "  (non-secret, echoed)
  local var=$1 prompt=$2 val=""
  [ -n "${!var:-}" ] && return 0
  [ -e /dev/tty ] || { echo "FATAL: $var unset and no TTY to prompt on — export it first" >&2; exit 1; }
  while [ -z "$val" ]; do
    printf '%s' "$prompt" > /dev/tty
    IFS= read -r val < /dev/tty
  done
  export "$var=$val"
}

ask_secret CB_PLUGIN_TOKEN "Docker Hub read-only token for tensormesh/cacheblend-plugin: "
ask_plain  TMO_GHCR_USER   "GHCR username: "
ask_secret TMO_GHCR_TOKEN  "GHCR read:packages token (chart): "
# HF_TOKEN is OPTIONAL and not prompted: openai/gpt-oss-120b is Apache-2.0 and
# UNGATED (HF API: gated=false, private=false) — the Brev run pulled gpt-oss-20b
# with no token at all. Export HF_TOKEN only if you want authenticated pulls
# (higher anonymous rate limits) or later swap in a gated model (e.g. Llama).
HF_TOKEN="${HF_TOKEN:-}"
CB_PLUGIN_USER="${CB_PLUGIN_USER:-tensormesh}"
CHART_VERSION="${CHART_VERSION:-0.5.2}"
STACK_TAG="${STACK_TAG:-v0.5.3}"
NS_OP="${NS_OP:-tensormesh-operator}"
NS_WL="${NS_WL:-cacheblend-workload}"
SKIP_BASELINE="${SKIP_BASELINE:-0}"
CERTMGR_VERSION="v1.16.2"   # exact version proven in the Brev run
ENG="${ENG:-tensormesh-cacheblend}"      # CacheBlendEngine name (= values cacheBlend.name)
ENG_HTTP="${ENG_HTTP:-8080}"             # engine FastAPI frontend: /status AND /metrics
HF_PVC="${HF_PVC:-hf-cache}"             # persist ~65GB of weights across pod restarts
HF_PVC_SIZE="${HF_PVC_SIZE:-120Gi}"      # nominal: nfs-subdir does NOT enforce this

WORKDIR="$HOME/tmo-launchpad-setup"; mkdir -p "$WORKDIR"
exec > >(tee -a "$WORKDIR/setup.log") 2>&1
echo "=== setup start $(date -u +%FT%TZ) — chart $CHART_VERSION / stack $STACK_TAG ==="

step() { printf '\n############ %s ############\n' "$*"; }
fail() { echo "FATAL: $*" >&2; exit 1; }
# poll "<desc>" <tries> <sleep_s> <cmd...>  — gate that retries until cmd succeeds
poll() {
  local desc=$1 tries=$2 slp=$3; shift 3
  local i=1
  while [ "$i" -le "$tries" ]; do
    if "$@" >/dev/null 2>&1; then echo "GATE OK: $desc"; return 0; fi
    echo "  ...waiting ($i/$tries): $desc"; sleep "$slp"; i=$((i+1))
  done
  fail "gate never passed: $desc"
}

############################################################
step "PHASE 0 — tooling, login, node"
############################################################
for c in kubectl helm; do command -v "$c" >/dev/null || fail "$c not on PATH"; done
kubectl get ns >/dev/null 2>&1 || fail "not logged into the cluster (oc login / kubeconfig first)"
echo "logged in as: $(kubectl auth whoami -o jsonpath='{.status.userInfo.username}' 2>/dev/null || echo 'kubeconfig user')"
GPUS=$(kubectl get nodes -l nvidia.com/gpu.present=true \
  -o jsonpath='{range .items[*]}{.metadata.name}={.status.allocatable.nvidia\.com/gpu} {end}')
[ -n "$GPUS" ] || fail "no GPU nodes (nvidia.com/gpu.present=true)"
echo "GPU nodes: $GPUS"

############################################################
step "PHASE 1 — prerequisites (verified in PREP / runbook Step 0 — not re-checked)"
############################################################
cat <<'REQ'
This script assumes prep already confirmed:
  - can create rolebindings (chart binds the privileged SCC)
  - privileged SCC: allowHostIPC=true, allowPrivilegedContainer=true
  - no Gatekeeper/Kyverno vetoing privileged pods
  - a StorageClass EXISTS and its backing store has >= 80GB FREE
    (nfs-subdir does not enforce PVC size — only prep's df probe proves capacity)
  - GPU node with nvidia.com/gpu allocatable
Re-run the Step 0 checks first if any of that is in doubt.
REQ

############################################################
step "PHASE 2 — cert-manager (webhook serving cert)"
############################################################
if ! kubectl get crd certificates.cert-manager.io >/dev/null 2>&1; then
  echo "installing cert-manager $CERTMGR_VERSION"
  kubectl apply -f "https://github.com/cert-manager/cert-manager/releases/download/$CERTMGR_VERSION/cert-manager.yaml"
else
  echo "cert-manager CRDs already present"
fi
# Only wait on deployments that exist in the cert-manager ns — a pre-existing
# OLM install lives in openshift-operators and would fail this check while being
# perfectly healthy. The admit probe below is the real gate either way.
for d in cert-manager cert-manager-webhook cert-manager-cainjector; do
  if kubectl -n cert-manager get deploy "$d" >/dev/null 2>&1; then
    kubectl -n cert-manager rollout status deploy/$d --timeout=300s
  else
    echo "  (no deploy/$d in ns cert-manager — assuming another install location)"
  fi
done
# the webhook must actually ADMIT — dry-run a no-op Issuer until it does
poll "cert-manager webhook admits requests" 30 5 \
  kubectl apply --dry-run=server -f - <<'EOF'
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata: { name: certmgr-probe }
spec: { selfSigned: {} }
EOF

############################################################
step "PHASE 3 — namespaces, PSA labels, secrets"
############################################################
kubectl get ns "$NS_OP" >/dev/null 2>&1 || kubectl create ns "$NS_OP"
kubectl get ns "$NS_WL" >/dev/null 2>&1 || kubectl create ns "$NS_WL"
# stop the OpenShift PSA label-syncer flipping the privileged label back
kubectl label ns "$NS_WL" security.openshift.io/scc.podSecurityLabelSync=false --overwrite
# All THREE PSA channels: enforce decides admission; audit/warn only log. Left at
# their defaults, audit/warn=restricted spam the operator log with
# 'would violate PodSecurity "restricted:latest": host namespaces (hostIPC=true)'
# for every engine/vLLM pod — alarming but harmless, since enforce=privileged is
# what actually admits them.
kubectl label ns "$NS_WL" pod-security.kubernetes.io/enforce=privileged --overwrite
kubectl label ns "$NS_WL" pod-security.kubernetes.io/audit=privileged   --overwrite
kubectl label ns "$NS_WL" pod-security.kubernetes.io/warn=privileged    --overwrite
LBL=$(kubectl get ns "$NS_WL" -o jsonpath='{.metadata.labels.pod-security\.kubernetes\.io/enforce}')
[ "$LBL" = "privileged" ] || fail "$NS_WL PSA enforce label is '$LBL', not privileged"

kubectl -n "$NS_WL" create secret docker-registry cacheblend-plugin-pull \
  --docker-server=https://index.docker.io/v1/ \
  --docker-username="$CB_PLUGIN_USER" --docker-password="$CB_PLUGIN_TOKEN" \
  --dry-run=client -o yaml | kubectl apply -f -
# PRIVILEGED SA — chart gap (hit on Launchpad 2026-08-07): with
# openshift.enabled=true the chart creates <release>-engine-privileged + its SCC
# RoleBinding in the RELEASE namespace, but the CacheBlendEngine runs in
# cacheBlend.namespace. When those differ, the engine DaemonSet dies with
#   FailedCreate: error looking up service account <ns>/tensormesh-operator-engine-privileged:
#   serviceaccount ... not found
# so create it (idempotently) in the WORKLOAD namespace before the chart lands.
# The injected vLLM pod needs the same SA anyway (hostIPC).
SA="${SA:-tensormesh-operator-engine-privileged}"
kubectl -n "$NS_WL" get sa "$SA" >/dev/null 2>&1 || kubectl -n "$NS_WL" create sa "$SA"
kubectl -n "$NS_WL" create rolebinding "${SA}-scc" \
  --clusterrole=system:openshift:scc:privileged \
  --serviceaccount="$NS_WL:$SA" \
  --dry-run=client -o yaml | kubectl apply -f -
echo "privileged SA ready: $NS_WL/$SA (+ SCC rolebinding)"

# hf-token-secret only if a token was supplied — the model is ungated, and both
# Deployments reference this secret with optional: true so its absence is fine.
if [ -n "$HF_TOKEN" ]; then
  kubectl -n "$NS_WL" create secret generic hf-token-secret \
    --from-literal=HF_TOKEN="$HF_TOKEN" \
    --dry-run=client -o yaml | kubectl apply -f -
  echo "secrets in place (incl. hf-token-secret)"
else
  echo "secrets in place (no HF_TOKEN given — gpt-oss-120b is ungated, pulling anonymously)"
fi

############################################################
step "PHASE 3b — HF cache PVC (weights persist across restarts)"
############################################################
# gpt-oss-120b is ~65GB. On emptyDir every pod recreate re-downloads it, and the
# bench cycle parks/unparks arms repeatedly. Prefer a PVC shared by BOTH arms.
# nfs-client is proven present on Launchpad (Marc's baselines use it, RWX);
# else fall back to the cluster default SC (RWO is fine — single-node cluster,
# and RWO permits multiple pods on the SAME node); else emptyDir.
HF_VOL="emptyDir: { sizeLimit: 200Gi }"
SC=""; AM="ReadWriteMany"
if kubectl get sc nfs-client >/dev/null 2>&1; then
  SC="nfs-client"
else
  SC=$(kubectl get sc -o jsonpath='{range .items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")]}{.metadata.name}{end}' 2>/dev/null || true)
  [ -n "$SC" ] && AM="ReadWriteOnce"
fi
if [ -n "$SC" ]; then
  echo "using storageClass '$SC' ($AM) for the HF cache PVC"
  kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: $HF_PVC, namespace: $NS_WL }
spec:
  accessModes: [$AM]
  storageClassName: $SC
  resources: { requests: { storage: $HF_PVC_SIZE } }
EOF
  # WaitForFirstConsumer SCs stay Pending until a pod mounts — Pending is OK here.
  PH=$(kubectl -n "$NS_WL" get pvc "$HF_PVC" -o jsonpath='{.status.phase}' 2>/dev/null || true)
  echo "PVC $HF_PVC phase: ${PH:-unknown}"
  HF_VOL="persistentVolumeClaim: { claimName: $HF_PVC }"
  # Capacity is a PREP requirement (>= 80GB free on the backing store) — prep's df
  # probe is the only thing that proves it, since nfs-subdir binds any requested
  # size without enforcing it. Not re-checked here.
else
  echo "WARN: no nfs-client and no default StorageClass — falling back to emptyDir"
  echo "      (weights re-download on every pod recreate: ~65GB each time)"
fi

############################################################
step "PHASE 4 — chart values"
############################################################
cat > "$WORKDIR/values-cacheblend-launchpad.yaml" <<EOF
crds: { enabled: true }
fullnameOverride: tensormesh-operator
openshift:
  enabled: true                # SA <release>-engine-privileged + SCC RoleBinding (docs)
webhook: { enabled: true }     # vLLM track uses the webhook (args-only pods)
tests:   { enabled: false }
engine:      { enabled: false }
coordinator: { enabled: false }
cacheBlend:
  enabled: true
  name: tensormesh-cacheblend
  namespace: $NS_WL
  spec:
    privileged: true
    l1: { sizeGB: 200 }        # node has ~2.1 TiB RAM; 200GB = reference run
    server: { chunkSize: 256 } # FIXED at 256 for CacheBlend
    image:
      repository: lmcache/vllm-openai
      tag: $STACK_TAG
      pullPolicy: IfNotPresent
    blend:
      checkLayer: 1
      recompRatio: 0.15
    injection:
      payloadImage:
        repository: tensormesh/cacheblend-plugin
        tag: $STACK_TAG
        pullPolicy: IfNotPresent
      imagePullSecrets:
        - name: cacheblend-plugin-pull
      cudagraph: eager
EOF
echo "values written: $WORKDIR/values-cacheblend-launchpad.yaml"

############################################################
step "PHASE 5 — TMO operator (chart $CHART_VERSION) + webhook wiring gates"
############################################################
helm registry login ghcr.io -u "$TMO_GHCR_USER" --password-stdin <<<"$TMO_GHCR_TOKEN"
helm upgrade --install tensormesh-operator \
  oci://ghcr.io/tensormesh-production/charts/tensormesh-operator \
  --version "$CHART_VERSION" -n "$NS_OP" --create-namespace \
  -f "$WORKDIR/values-cacheblend-launchpad.yaml" --wait --timeout 15m

kubectl -n "$NS_OP" rollout status deploy/tensormesh-operator --timeout=300s
poll "webhook caBundle injected by cert-manager" 60 3 \
  sh -c "[ -n \"\$(kubectl get mutatingwebhookconfiguration tensormesh-operator-mutating-webhook -o jsonpath='{.webhooks[0].clientConfig.caBundle}' 2>/dev/null)\" ]"
poll "CacheBlendEngine CR reconciled (connection ConfigMap)" 60 3 \
  kubectl -n "$NS_WL" get configmap tensormesh-cacheblend-connection

############################################################
step "PHASE 6 — blend engine Ready on CUDA backend (recycle if CPU stub)"
############################################################
poll "blend engine pod exists" 60 5 \
  sh -c "kubectl -n '$NS_WL' get pod -l app.kubernetes.io/component=cache-engine -o name | grep -q ."
# NOTE: --all-containers=true is load-bearing. If the engine pod has more than one
# container, plain `kubectl logs <pod>` errors with "a container name must be
# specified" — which, swallowed by 2>/dev/null, makes the banner gate spin for its
# whole budget while the engine is perfectly healthy (hit on Launchpad 2026-08-07).
elogs() { kubectl -n "$NS_WL" logs "$1" --all-containers=true --tail=-1 2>/dev/null; }
try=1
while :; do
  BLEND=$(kubectl -n "$NS_WL" get pod -l app.kubernetes.io/component=cache-engine -o name | head -1)
  kubectl -n "$NS_WL" wait --for=condition=Ready "$BLEND" --timeout=900s

  # Backend detection is VERSION-DEPENDENT (learned on Launchpad 2026-08-07):
  #   v0.5.0 logs  "Using backend: lmcache.c_ops"
  #   v0.5.3 dropped that line entirely; CUDA now shows up as the cuda platform
  #          module path / torch device type instead.
  # So match a SET of CUDA tells, treat only an explicit stub as failure, and never
  # hard-fail merely because no known string appeared.
  CUDA_RE='Using backend: lmcache\.c_ops|platform\.cuda|torch_device_type=cuda|CudaPinMemoryBackend'
  STUB_RE='StubCPUDevice|Using backend: lmcache\.cpu'
  i=1; BANNER=""
  while [ "$i" -le 24 ]; do
    L=$(elogs "$BLEND")
    BANNER=$(echo "$L" | grep -E "$STUB_RE" | tail -1 || true)
    [ -n "$BANNER" ] && break
    BANNER=$(echo "$L" | grep -E "$CUDA_RE" | tail -1 || true)
    [ -n "$BANNER" ] && break
    echo "  ...waiting ($i/24): engine backend evidence in logs"; sleep 5; i=$((i+1))
  done

  if [ -z "$BANNER" ]; then
    echo "WARN: no backend evidence in logs (unknown log format for this version)."
    echo "      Engine pod is Ready; continuing. Verify manually:"
    echo "      kubectl -n $NS_WL logs $BLEND --all-containers=true | grep -iE 'cuda|backend|pin'"
    break
  fi
  echo "engine backend evidence: $BANNER"
  case "$BANNER" in
    *StubCPUDevice*|*"lmcache.cpu"*) : ;;   # fall through to the recycle below
    *) echo "blend engine on CUDA ✓"; break ;;
  esac
  [ "$try" -ge 2 ] && fail "blend engine stuck on CPU stub after recycle — driver/runtime?"
  echo "engine on CPU stub (attempt $try) — recycling pod"
  kubectl -n "$NS_WL" delete "$BLEND"; sleep 10; try=$((try+1))
done

############################################################
step "PHASE 7 — SCC go/no-go probe (dry-run hostIPC pod under the privileged SA)"
############################################################
# $SA was created in PHASE 3 (chart puts its own copy in the release namespace,
# which the engine/vLLM pods in $NS_WL cannot use). Confirm it is really there.
kubectl -n "$NS_WL" get sa "$SA" >/dev/null 2>&1 \
  || fail "privileged SA $NS_WL/$SA missing — PHASE 3 should have created it"
echo "privileged SA: $SA"
kubectl -n "$NS_WL" apply --dry-run=server -f - <<EOF
apiVersion: v1
kind: Pod
metadata: { name: scc-probe }
spec:
  serviceAccountName: $SA
  hostIPC: true
  containers: [{ name: p, image: registry.access.redhat.com/ubi9/ubi-minimal, command: ["sleep","1"] }]
EOF
echo "hostIPC admission ✓ (server dry-run)"

############################################################
step "PHASE 8 — vLLM arms (A baseline, B CacheBlend) + injection gates"
############################################################
# fsGroup from the namespace's OpenShift-assigned GID range, so the arbitrary UID
# the pod runs as can write to the NFS-backed PVC. Emits nothing on a cluster that
# doesn't assign ranges (plain k8s), keeping the manifest valid either way.
FSGROUP=$(kubectl get ns "$NS_WL" \
  -o jsonpath='{.metadata.annotations.openshift\.io/sa\.scc\.supplemental-groups}' 2>/dev/null \
  | cut -d/ -f1)
fsgroup_block() {
  [ -n "${FSGROUP:-}" ] && printf '      securityContext: { fsGroup: %s }\n' "$FSGROUP"
  return 0
}
[ -n "${FSGROUP:-}" ] && echo "pods will run with fsGroup $FSGROUP (from $NS_WL annotation)"

# OpenShift arbitrary-UID survival kit (from Marc's baselines; hit for real on
# 2026-08-07: "OSError: PermissionError at /.cache when downloading
# openai/gpt-oss-120b"). The container does NOT run as root here, so $HOME is "/"
# and every library that writes to ~/.cache lands on a read-only path. Redirect
# HF to the mounted PVC and everything else to /tmp. USER/LOGNAME are set because
# some libs call getpwuid() on a UID that has no /etc/passwd entry.
common_env() { cat <<EOF
            - { name: HF_HOME,                 value: /opt/models }
            - { name: HOME,                    value: /tmp }
            - { name: USER,                    value: dynamo }
            - { name: LOGNAME,                 value: dynamo }
            - { name: TORCHINDUCTOR_CACHE_DIR, value: /tmp/torchinductor }
            - { name: TRITON_CACHE_DIR,        value: /tmp/.triton-cache }
            - { name: VLLM_CACHE_ROOT,         value: /tmp/vllm-cache }
            - { name: HF_MODULES_CACHE,        value: /tmp/hf_modules }
            - { name: HF_HUB_DISABLE_TELEMETRY, value: "1" }
            - { name: VLLM_USE_FLASHINFER_MOE_FP8, value: "0" }
EOF
}

common_args() { cat <<EOF
            - openai/gpt-oss-120b
            - --served-model-name=openai/gpt-oss-120b
            - --trust-remote-code
            - --tensor-parallel-size=1
            - --max-model-len=45056
            - --max-num-batched-tokens=45056
            - --max-num-seqs=8
            - --gpu-memory-utilization=0.90
            - --block-size=64
            - --no-enable-chunked-prefill
            - --no-enable-prefix-caching
EOF
}

if [ "$SKIP_BASELINE" != "1" ]; then
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: gptoss120b-base
  namespace: $NS_WL
  labels: { app: gptoss120b-base }
spec:
  replicas: 1
  selector: { matchLabels: { app: gptoss120b-base } }
  template:
    metadata:
      labels: { app: gptoss120b-base }
    spec:
$(fsgroup_block)
      tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]
      containers:
        - name: vllm
          image: lmcache/vllm-openai:$STACK_TAG
          imagePullPolicy: IfNotPresent
          args:
$(common_args)
            - --enforce-eager
          env:
$(common_env)
          envFrom: [{ secretRef: { name: hf-token-secret, optional: true } }]
          ports: [{ name: http, containerPort: 8000 }]
          volumeMounts: [{ name: cache, mountPath: /opt/models }]
          resources:
            limits:   { nvidia.com/gpu: "1", memory: 128Gi }
            requests: { cpu: "8", memory: 64Gi }
          readinessProbe:
            httpGet: { path: /health, port: http }
            initialDelaySeconds: 120
            periodSeconds: 15
            failureThreshold: 120
      volumes: [{ name: cache, $HF_VOL }]
---
apiVersion: v1
kind: Service
metadata: { name: gptoss120b-base, namespace: $NS_WL }
spec:
  selector: { app: gptoss120b-base }
  ports: [{ name: http, port: 8000, targetPort: http }]
EOF
# Serialize: let arm A pull the weights into the shared PVC and reach Ready before
# arm B starts (avoids two concurrent 65GB HF downloads into one cache dir).
kubectl -n "$NS_WL" rollout status deploy/gptoss120b-base --timeout=2400s
fi

# GATE (from TMO's e2e): the engine must hold NO stale GPU registrations before a
# new vLLM pod starts. A dead vLLM's KV stays pinned via the engine's imported CUDA
# IPC mappings until its reaper drops the silent instance (~120s) — start inside
# that window and vLLM fails its precheck: "Free memory on device cuda:0 ... less
# than desired". Warn-and-continue, like the e2e does.
echo "checking engine has no stale GPU registrations (reap window ~120s)..."
i=1
while [ "$i" -le 36 ]; do
  ST=$(kubectl get --raw "/api/v1/namespaces/$NS_WL/services/${ENG}:${ENG_HTTP}/proxy/status" 2>/dev/null | tr -d ' ' || true)
  case "$ST" in
    *'"registered_gpu_ids":[]'*) echo "GATE OK: engine idle (0 registered GPU instances)"; break ;;
  esac
  [ -z "$ST" ] && { echo "  (engine /status unreachable — skipping idle gate)"; break; }
  echo "  ...engine still holds registrations ($i/36)"; sleep 5; i=$((i+1))
done

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: gptoss120b-cb
  namespace: $NS_WL
  labels: { app: gptoss120b-cb }
spec:
  replicas: 1
  selector: { matchLabels: { app: gptoss120b-cb } }
  template:
    metadata:
      labels:
        app: gptoss120b-cb
        lmcache.ai/cacheblend-inject: "true"
      annotations:
        lmcache.ai/cacheblend-engine: "tensormesh-cacheblend"
    spec:
      serviceAccountName: $SA
$(fsgroup_block)
      # 120s grace + VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS=60 below (TMO e2e lesson):
      # vLLM's executor gives workers only 5s by default, so on shutdown the workers'
      # UNREGISTER_KV_CACHE never leaves the process and ~60GB of KV stays pinned on
      # the engine's imported CUDA IPC mappings until its 120s reaper — which then
      # breaks the NEXT pod's free-VRAM precheck. Grace must exceed the inner budget.
      terminationGracePeriodSeconds: 120
      tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]
      containers:
        - name: vllm
          image: lmcache/vllm-openai:$STACK_TAG
          imagePullPolicy: IfNotPresent
          args:
$(common_args)
            # perf parity with Weishu's measured reference (both modes supported;
            # this one is faster). TMO's e2e passes WITHOUT it — drop it first if
            # the CB arm misbehaves.
            - --disable-hybrid-kv-cache-manager
          env:
$(common_env)
            - { name: VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS, value: "60" }
            - { name: LMCACHE_CHUNK_SIZE,          value: "256" }
            - { name: LMCACHE_MAX_LOCAL_CPU_SIZE,  value: "60" }
            - { name: LMCACHE_LMCACHE_INSTANCE_ID, value: "cb_gpt_oss_120b" }
            - { name: LMCACHE_USE_LAYERWISE,       value: "False" }
          envFrom: [{ secretRef: { name: hf-token-secret, optional: true } }]
          ports: [{ name: http, containerPort: 8000 }]
          volumeMounts: [{ name: cache, mountPath: /opt/models }]
          resources:
            limits:   { nvidia.com/gpu: "1", memory: 128Gi }
            requests: { cpu: "8", memory: 64Gi }
          readinessProbe:
            httpGet: { path: /health, port: http }
            initialDelaySeconds: 120
            periodSeconds: 15
            failureThreshold: 120
      volumes: [{ name: cache, $HF_VOL }]
---
apiVersion: v1
kind: Service
metadata: { name: gptoss120b-cb, namespace: $NS_WL }
spec:
  selector: { app: gptoss120b-cb }
  ports: [{ name: http, port: 8000, targetPort: http }]
EOF

# GATE: the CB pod must be MUTATED — hostIPC=true; re-admit up to 5x (proven flake on Brev)
i=1
while :; do
  sleep 15
  POD=$(kubectl -n "$NS_WL" get pod -l app=gptoss120b-cb -o name 2>/dev/null | head -1 || true)
  if [ -n "$POD" ] && [ "$(kubectl -n "$NS_WL" get "$POD" -o jsonpath='{.spec.hostIPC}')" = "true" ]; then
    echo "webhook injection verified (hostIPC=true) ✓"; break
  fi
  [ "$i" -ge 5 ] && fail "webhook never injected the CB pod (5 attempts)"
  echo "pod not injected (attempt $i) — scale 0->1 to re-admit"
  kubectl -n "$NS_WL" scale deploy/gptoss120b-cb --replicas=0; sleep 10
  kubectl -n "$NS_WL" scale deploy/gptoss120b-cb --replicas=1; i=$((i+1))
done
# report whether the webhook added disable-hybrid (Weishu's measured cmd has it)
kubectl -n "$NS_WL" get "$POD" -o jsonpath='{.spec.containers[0].args}' | tr ',' '\n' \
  | grep -q 'disable-hybrid-kv-cache-manager' \
  && echo "webhook injected --disable-hybrid-kv-cache-manager ✓" \
  || echo "NOTE: --disable-hybrid-kv-cache-manager NOT injected — add to base args to match Weishu's reference"

# GATE: CB rollout (arm A already gated above; weights now come from the PVC)
kubectl -n "$NS_WL" rollout status deploy/gptoss120b-cb --timeout=2400s

# GATE: CBKVConnector actually created in the CB engine core
poll "CBKVConnector created in CB pod logs" 30 10 \
  sh -c "kubectl -n '$NS_WL' logs deploy/gptoss120b-cb 2>/dev/null | grep -q 'CBKVConnector'"

############################################################
step "PHASE 9 — in-cluster smoke (both arms answer /v1/models + a completion)"
############################################################
smoke() { # smoke <svc>
  kubectl -n "$NS_WL" run "smoke-$1" --rm -i --restart=Never --quiet \
    --image=registry.access.redhat.com/ubi9/ubi-minimal -- \
    sh -c "curl -sf http://$1:8000/v1/models >/dev/null && \
           curl -sf -X POST http://$1:8000/v1/completions -H 'Content-Type: application/json' \
             -d '{\"model\":\"openai/gpt-oss-120b\",\"prompt\":\"hello\",\"max_tokens\":4}' >/dev/null && \
           echo SMOKE-OK-$1"
}
[ "$SKIP_BASELINE" != "1" ] && { smoke gptoss120b-base | grep -q SMOKE-OK || fail "baseline smoke failed"; }
smoke gptoss120b-cb | grep -q SMOKE-OK || fail "CB smoke failed"
echo "no-degradation check:"
kubectl -n "$NS_WL" logs deploy/gptoss120b-cb | grep -hoE "[0-9]+ degraded" | sort -u || echo "(no degraded lines yet — appears under blend traffic)"

# Engine registered this model's KV layout? (bench needs it; pod can be Ready first)
echo "engine /status — model KV layout registered:"
kubectl get --raw "/api/v1/namespaces/$NS_WL/services/${ENG}:${ENG_HTTP}/proxy/status" 2>/dev/null \
  | grep -oE '"(registered_gpu_ids|cache_size_per_token)":[^,}]*' || echo "  (/status unreachable via API proxy)"

# Blend metrics endpoint must be live BEFORE the bench — that's the real gate later
# (per TMO's e2e: gate on the non_prefix_hit_tokens DELTA, never on [match_probe]
# logs, which a coordinator-wired engine never emits).
echo "engine /metrics — blend counters present:"
kubectl get --raw "/api/v1/namespaces/$NS_WL/services/${ENG}:${ENG_HTTP}/proxy/metrics" 2>/dev/null \
  | grep -oE '^lmcache_blend_[a-z0-9_]+' | sort -u | head -10 \
  || echo "  WARN: /metrics unreachable — bench verification must fall back to scatter logs"

############################################################
step "DONE"
############################################################
cat > "$WORKDIR/READY.txt" <<EOF
=== Launchpad CacheBlend vLLM track READY $(date -u +%FT%TZ) ===
chart: $CHART_VERSION   stack: $STACK_TAG   ns: $NS_WL   privileged SA: $SA
arms:  gptoss120b-base (:8000) $([ "$SKIP_BASELINE" = "1" ] && echo '[SKIPPED]') | gptoss120b-cb (:8000)

bench (run against EACH arm's svc, same params — Weishu reference):
  python cacheblend-plugin/benchmarks/long_doc_permutator.py \\
    --engine-url http://<svc>:8000 --model openai/gpt-oss-120b \\
    --tokenizer openai/gpt-oss-120b --num-contexts 16 --context-length 2559 \\
    --system-prompt-length 245 --num-permutations 50 --num-inflight-requests 8 \\
    --vocab-size 40000 --max-output-length 1 --seed 42 --output bench_summary.json
reference to beat (1xH200 TP1, APC off): duration/throughput 3.05x, P50 TTFT 2.89x

BLEND VERIFICATION — snapshot the counter BEFORE the bench, gate on the DELTA
(TMO e2e method; counters are cumulative over the engine's lifetime).
Do NOT gate on [match_probe] logs — a coordinator-wired engine never emits them.
  M=/api/v1/namespaces/$NS_WL/services/${ENG}:${ENG_HTTP}/proxy/metrics
  np() { kubectl get --raw "\$M" | awk '\$1 ~ /^lmcache_blend_lookup_non_prefix_hit_tokens(_total)?(\{|\$)/ {s+=\$2} END{printf "%d", s}'; }
  BASE=\$(np)    # before the bench
  ...run the bench...
  echo "non-prefix tokens served from blend this run: \$(( \$(np) - BASE ))"   # must be > 0
Hit rate (informational, cumulative):
  non_prefix_hit_tokens / lmcache_blend_lookup_requested_tokens  from the same endpoint

vLLM-side checks:
  kubectl -n $NS_WL logs deploy/gptoss120b-cb | grep -c "CB\[start_load_kv\]"     # > 0
  kubectl -n $NS_WL logs deploy/gptoss120b-cb | grep -hoE "[0-9]+ degraded" | sort -u  # only "0 degraded"

RESTART DISCIPLINE (bench cycles): after deleting/parking a vLLM arm, wait for the
engine to report registered_gpu_ids: [] before starting the next pod, else its
free-VRAM precheck fails on KV still pinned via CUDA IPC (~120s reaper):
  kubectl get --raw /api/v1/namespaces/$NS_WL/services/${ENG}:${ENG_HTTP}/proxy/status
EOF
cat "$WORKDIR/READY.txt"
