#!/bin/bash
###############################################################################
# teardown-tmo-cb-launchpad.sh — remove everything setup-tmo-cb-launchpad.sh made,
# so the installer can be re-run from a clean slate.
#
# KEEPS cert-manager on purpose: it is a prerequisite, slow to reinstall, and the
# installer skips it when the CRD is already present. Pass WIPE_CERTMANAGER=1 to
# remove it too.
#
# KEEPS nothing else — including the hf-cache PVC, so the ~65GB of gpt-oss-120b
# weights are deleted with the namespace. Pass KEEP_WORKLOAD_NS=1 to preserve the
# namespace (and therefore the warm weight cache) and only remove the TMO objects.
#
# Usage:
#   bash teardown-tmo-cb-launchpad.sh
#   KEEP_WORKLOAD_NS=1 bash teardown-tmo-cb-launchpad.sh      # keep weights
###############################################################################
set -u

NS_OP="${NS_OP:-tensormesh-operator}"
NS_WL="${NS_WL:-cacheblend-workload}"
KEEP_WORKLOAD_NS="${KEEP_WORKLOAD_NS:-0}"
WIPE_CERTMANAGER="${WIPE_CERTMANAGER:-0}"

say() { printf '\n==== %s ====\n' "$*"; }

say "1/6 engine CR (operator tears down its DaemonSet)"
kubectl -n "$NS_WL" delete cacheblendengine --all --ignore-not-found --timeout=120s
kubectl -n "$NS_WL" delete lmcacheengine --all --ignore-not-found --timeout=120s 2>/dev/null
kubectl -n "$NS_WL" delete lmcachecoordinator --all --ignore-not-found --timeout=120s 2>/dev/null

say "2/6 vLLM arms"
kubectl -n "$NS_WL" delete deploy gptoss120b-base gptoss120b-cb --ignore-not-found
kubectl -n "$NS_WL" delete svc    gptoss120b-base gptoss120b-cb --ignore-not-found
# stray probes from earlier runs
kubectl -n "$NS_WL" delete pod hf-cache-probe scc-probe --ignore-not-found 2>/dev/null
kubectl -n default   delete pod df-probe --ignore-not-found 2>/dev/null
kubectl -n default   delete pvc df-probe --ignore-not-found 2>/dev/null

say "3/6 helm release"
helm uninstall tensormesh-operator -n "$NS_OP" --wait --timeout 5m 2>/dev/null \
  || echo "(no release, or already gone)"

say "4/6 namespaces"
if [ "$KEEP_WORKLOAD_NS" = "1" ]; then
  echo "keeping $NS_WL (and the hf-cache PVC / warm weights)"
  kubectl -n "$NS_WL" delete secret cacheblend-plugin-pull hf-token-secret --ignore-not-found
  kubectl -n "$NS_WL" delete sa tensormesh-operator-engine-privileged --ignore-not-found
  kubectl -n "$NS_WL" delete rolebinding tensormesh-operator-engine-privileged-scc --ignore-not-found
else
  kubectl delete ns "$NS_WL" --ignore-not-found --timeout=180s
fi
kubectl delete ns "$NS_OP" --ignore-not-found --timeout=180s

say "5/6 cluster-scoped leftovers (CRDs, webhook, cluster roles)"
kubectl delete mutatingwebhookconfiguration tensormesh-operator-mutating-webhook --ignore-not-found
kubectl delete validatingwebhookconfiguration tensormesh-operator-validating-webhook --ignore-not-found 2>/dev/null
CRDS=$(kubectl get crd -o name 2>/dev/null | grep -i 'lmcache' || true)
if [ -n "$CRDS" ]; then echo "$CRDS" | xargs -r kubectl delete --ignore-not-found; else echo "no lmcache CRDs"; fi
CR=$(kubectl get clusterrole,clusterrolebinding -o name 2>/dev/null | grep -i 'tensormesh' || true)
if [ -n "$CR" ]; then echo "$CR" | xargs -r kubectl delete --ignore-not-found; else echo "no tensormesh cluster roles"; fi

if [ "$WIPE_CERTMANAGER" = "1" ]; then
  say "cert-manager (WIPE_CERTMANAGER=1)"
  kubectl delete -f https://github.com/cert-manager/cert-manager/releases/download/v1.16.2/cert-manager.yaml --ignore-not-found
else
  say "cert-manager KEPT (set WIPE_CERTMANAGER=1 to remove)"
fi

say "6/6 verify clean"
echo "-- namespaces:";  kubectl get ns | grep -E "$NS_OP|$NS_WL" || echo "   both gone ✓"
echo "-- lmcache CRDs:"; kubectl get crd 2>/dev/null | grep -i lmcache || echo "   none ✓"
echo "-- webhooks:";     kubectl get mutatingwebhookconfiguration 2>/dev/null | grep -i tensormesh || echo "   none ✓"
echo "-- helm:";         helm list -A 2>/dev/null | grep -i tensormesh || echo "   no release ✓"
echo
echo "Ready to re-run: bash setup-tmo-cb-launchpad.sh"
